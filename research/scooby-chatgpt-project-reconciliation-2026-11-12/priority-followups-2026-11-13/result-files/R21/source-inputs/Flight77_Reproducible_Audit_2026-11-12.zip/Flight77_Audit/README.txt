FLIGHT 77 CHANNEL VALIDATION AUDIT - SCOOBY BRIEF 14 / N03
Audit date: 12 November 2026

Read Flight77_Channel_Validation_Audit_2026-11-12.pdf first.

This is the public-source documentary audit actually performed. Native ChatGPT
Deep Research could not be launched or resumed in the session. The earlier
brief's submission was recovered; a completed prior result was not found in
accessible records. No contact, request, fee or pending-matter change occurred.

REPRODUCE THE SUPPORTED CALCULATIONS
From this extracted directory, with Python 3 (standard library only):
  python3 reproduce.py --output recalculated.json

The script verifies the exact CSV and database hashes and reproduces export
occupancy, endpoint cells, pressure differences, and original/synthetic bit
assembly examples. calculations.json is the output generated for this report.
It does not decode the compressed raw FDR, run downloaded third-party software,
decode a radar trajectory or infer an impact time or physical contradiction.

FILES
parameter_validation_ledger.json: addresses, source slots, sampling, conversion,
validation and missing installation/invalid-data evidence.
source_manifest.json: exact original and archive URLs, capture dates, bytes,
SHA-256 hashes, provenance limits and bundle locations.
sources/: official documents/exports and clearly identified archived attachment
and raw candidates. The Boeing manual is linked and hashed in the manifest; its
full copyrighted text is not republished. All facts required by reproduce.py
are documented in the report and script.
unvalidated_derivatives/: author-produced preceding-flight/door data. They are
preserved as leads, not independently calibrated measurement records.
PACKAGE_SHA256SUMS.txt: fingerprints for delivered files.

BOUNDARIES
NTSB classified pressure altitude/barometric settings as validated, but placed
door, GMT/GPS time and radio-height fields in the not-working-or-unconfirmed
group. This audit retains that distinction. Neither sensor absence nor a
closed-door history follows from a label or constant bit.

The candidate CSV's 09:37:45 and 09:37:46 rows have no parameter values. The
last populated group is 09:37:44; this is not a raw-memory endpoint or impact
clock determination. Synthetic conversion examples are not recorded raw data.

Missing wiring, runtime/configuration, failure behavior, calibration, time
correlation and radar-clock/target joins stop dependent physical conclusions.
