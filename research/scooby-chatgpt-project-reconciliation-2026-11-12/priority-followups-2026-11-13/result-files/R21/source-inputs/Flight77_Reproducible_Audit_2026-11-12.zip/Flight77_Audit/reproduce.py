#!/usr/bin/env python3
"""Reproduce bounded Flight 77 document/export checks. Python 3, standard library.

This is not an FDR decompressor or a flight-path reconstruction. No downloaded
third-party code is executed. Synthetic examples are explicitly distinguished
from observed values in the candidate NTSB engineering-unit CSV.
"""
import argparse
import collections
import csv
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CSV_SHA = "70740505826cf97b4fd376a8c225f78c87b7b245f46a4dbbd44ce8c356631138"
DB_SHA = "374b269812aece0ad75f182f7864a324cadef04e735ebb296ad8b0ebba107e64"


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def require_hash(path, expected):
    actual = sha256(path)
    if actual != expected:
        raise ValueError(f"Input identity mismatch for {path.name}: {actual}")
    return actual


def seconds(value):
    h, m, s = map(int, value.split(":"))
    return 3600 * h + 60 * m + s


def signed(value, bits):
    return value - (1 << bits) if value & (1 << (bits - 1)) else value


def pressure_from_words(w29, w30):
    """Boeing Rev G p20: word bit 1 is integer LSB; omit W30 bits 12..10."""
    coarse = signed((w29 >> 2) & 0x3FF, 10)
    fine = (w30 >> 2) & 0x7F
    return 128 * coarse + fine


def literal_printout_pressure(w29, w30):
    """Literal signed10 ALT_COA + signed10 ALT_FIN; not a claim about RAPS."""
    return 128 * signed((w29 >> 2) & 0x3FF, 10) + signed((w30 >> 2) & 0x3FF, 10)


def encode_pressure_example(altitude):
    """Synthetic valid overlap pattern, solely to test the two interpretations."""
    coarse = (altitude // 128) & 0x3FF
    fine = (altitude & 0x1FF) | (0x200 if altitude < 0 else 0)
    return coarse << 2, fine << 2


def radio_from_words(w31, w32):
    """Rev G p27: W31 bit12 is sign, W32 bits1..2 are high data bits."""
    packed = (((w31 >> 11) & 1) << 13) | ((w32 & 3) << 11) | (w31 & 0x7FF)
    return signed(packed, 14)


def audit_csv(path):
    digest = require_hash(path, CSV_SHA)
    observations = {4: [], 84: [], 85: [], 185: []}
    counts = collections.Counter()
    time_only = []
    groups = collections.Counter()
    time_labels = []
    latest_time = None
    first_data_line = None
    last_data_line = None
    last_data_group = None
    measurement_rows = 0
    total_data_rows = 0
    with path.open(newline="", encoding="cp1252") as f:
        reader = csv.reader(f)
        preamble = [next(reader) for _ in range(9)]
        header_rows = [next(reader) for _ in range(4)]
        width = len(header_rows[0])
        if any(len(r) != width for r in header_rows):
            raise ValueError("Header widths disagree")
        headers = [" ".join(r[i].strip() for r in header_rows if r[i].strip())
                   for i in range(width)]
        expected = {4: "PRESSURE ALT (feet)", 84: "BARO COR NO. 1 (IN) (inHg)",
                    85: "BARO COR NO. 2 (IN) (inHg)", 185: "FRAME COUNTER ()"}
        for i, label in expected.items():
            if headers[i] != label:
                raise ValueError(f"Unexpected header at column {i+1}: {headers[i]}")
        for row in reader:
            line = reader.line_num
            if len(row) != width:
                raise ValueError(f"Row width mismatch at physical line {line}")
            total_data_rows += 1
            if row[0]:
                latest_time = row[0]
                time_labels.append(row[0])
            groups[latest_time] += 1
            if any(cell.strip() for cell in row[1:]):
                measurement_rows += 1
                first_data_line = first_data_line or line
                last_data_line, last_data_group = line, latest_time
            else:
                time_only.append({"physical_line": line, "time_label": row[0],
                                  "populated_parameter_cells": 0})
            for col in observations:
                if row[col].strip():
                    counts[col] += 1
                    observations[col].append({"physical_line": line,
                                              "export_time_group": latest_time,
                                              "value": row[col]})
        physical_lines = reader.line_num
    pressure_tail = observations[4][-3:]
    deltas = []
    for a, b in zip(pressure_tail, pressure_tail[1:]):
        dt = seconds(b["export_time_group"]) - seconds(a["export_time_group"])
        dz = int(b["value"]) - int(a["value"])
        deltas.append({"from": a["export_time_group"], "to": b["export_time_group"],
                       "pressure_altitude_change_ft": dz, "export_label_interval_s": dt,
                       "change_ft_per_export_second": dz / dt})
    return {
        "input_sha256": digest,
        "source_status": "Archived candidate NTSB Attachment III, converted export; not raw bits",
        "encoding": "cp1252", "columns": width, "physical_lines": physical_lines,
        "header_lines": [10, 11, 12, 13], "data_rows": total_data_rows,
        "measurement_rows": measurement_rows, "first_measurement_line": first_data_line,
        "last_measurement_line": last_data_line, "last_measurement_export_group": last_data_group,
        "time_only_rows": time_only, "labeled_seconds": len(time_labels),
        "consecutive_time_labels": all(seconds(b)-seconds(a)==1 for a,b in zip(time_labels,time_labels[1:])),
        "row_count_per_time_group_distribution": dict(collections.Counter(groups.values())),
        "fields": [{"column_1based": i+1, "header": headers[i], "nonempty_cells": counts[i],
                    "first": observations[i][:1], "last": observations[i][-3:]}
                   for i in observations],
        "pressure_tail_differences": deltas,
        "door_radio_gmt_columns_present": [h for h in headers if re.search(r"FLT DECK DOOR|RADIO HEIGHT|GMT|GPS TIME", h)],
        "limits": [
            "Time-group labels organize the export; subrow positions do not establish acquisition phase or latency.",
            "The pressure differences are arithmetic on published engineering values, not terrain clearance or impact descent rate.",
            "Blank cells can reflect export sampling schedules; no blanket invalid-data meaning is inferred.",
            "Absent columns do not establish absent sensors or unused raw channels."
        ]
    }


def database_fields(path):
    digest = require_hash(path, DB_SHA)
    data = path.read_text(encoding="cp1252")
    wanted = {"FLT_D_DR", "ALT_COA", "ALT_FIN", "PresAlt", "BARO_CR1", "BARO_CR2",
              "radalt", "RAD_H_F", "RAD_H_L", "RAD_H_M", "RAD_H_LC", "RAD_H_MC",
              "GMT", "GMT_HOUR", "GMT_MIN", "GMT_SEC", "GPS", "GPS_HOUR", "GPS_MIN", "GPS_SEC",
              "ADC_INVA", "FRMCNT"}
    result = []
    for m in re.finditer(r"^Uid:\s+([^\n]+)\n.*?(?=^Uid:|\Z)", data, re.M | re.S):
        block = m.group().rstrip()
        uid = m.group(1).strip()
        if uid in wanted:
            start = data.count("\n", 0, m.start()) + 1
            result.append({"uid": uid, "start_line": start,
                           "end_line": start + block.count("\n"), "definition": block})
    return {"sha256": digest, "status": "Generic database printout; installation and actual RAPS runtime not established",
            "fields": result}


def specification_examples():
    pressures = []
    for altitude, origin in [(34423, "Boeing Rev G p20 published example"),
                             (1000, "Synthetic example, not a recorded raw word pair"),
                             (-500, "Synthetic negative example, not a recorded raw word pair")]:
        w29, w30 = encode_pressure_example(altitude)
        pressures.append({"example_altitude_ft": altitude, "origin": origin,
                          "w29": w29, "w30": w30,
                          "boeing_reconstruction_ft": pressure_from_words(w29, w30),
                          "literal_database_sum_ft": literal_printout_pressure(w29, w30)})
    radio = []
    for altitude, w31, w32 in [(5000, 904, 2), (-500, 3596, 3)]:
        radio.append({"origin": "Boeing Rev G p27 published example", "expected_ft": altitude,
                      "w31": w31, "w32": w32,
                      "sign_relocated_result_ft": radio_from_words(w31, w32),
                      "naive_contiguous_signed14_result_ft": signed((w32 << 12) | w31, 14),
                      "naive_signed12_plus_high2_result_ft": signed(w31, 12) + 2048*w32})
    baro = int("5660", 8)
    return {
        "warning": "Specification and synthetic arithmetic only. No raw flight record is decoded by this program.",
        "pressure": pressures, "radio": radio,
        "baro": {"origin": "Boeing Rev G p21, Note4C", "recorded_octal": "5660",
                 "recorded_unsigned_integer": baro, "scale_inHg_per_count": 0.01,
                 "inHg": baro / 100, "hex_nibbles_if_misread_as_direct_BCD": [baro>>8, (baro>>4)&15, baro&15]},
        "frame_geometry": {"words_per_subframe": 256, "bits_per_word": 12,
                           "subframes_per_frame": 4, "seconds_per_frame": 4,
                           "bits_per_second": 256*12*4/4, "word_slot_seconds": 1/256,
                           "door_interval_seconds": 1/0.25,
                           "radio_sf234_intervals_seconds": [1,1,2],
                           "radio_sf234_nominal_sources": ["LRRA left D20", "LRRA right D21", "LRRA centre D22"],
                           "radio_source_limit": "Generic Rev G frame assignments, not proof of N644AA wiring or three working sensors"},
        "ATC_declared_composite_interval": {"start_UTC": "12:19:20", "end_UTC": "13:03:19",
                                            "seconds": seconds("13:03:19")-seconds("12:19:20"),
                                            "meaning": "Duration only; audio digitization rate is not absolute clock accuracy"}
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, default=ROOT/"sources"/"AAL77_tabular.csv")
    parser.add_argument("--database", type=Path, default=ROOT/"sources"/"757-3b_1.TXT")
    parser.add_argument("--output", type=Path, default=ROOT/"calculations.json")
    args = parser.parse_args()
    result = {"research_date": "2026-11-12", "csv_audit": audit_csv(args.csv),
              "database_fields": database_fields(args.database),
              "specification_examples": specification_examples()}
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    print(f"Wrote {args.output}; no raw recorder or radar trajectory was decoded.")


if __name__ == "__main__":
    main()
