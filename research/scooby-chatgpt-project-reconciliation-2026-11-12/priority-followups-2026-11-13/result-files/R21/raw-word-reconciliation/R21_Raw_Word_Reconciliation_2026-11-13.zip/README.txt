SCOOBY R21 - RAW-WORD TO ENGINEERING-EXPORT RECONCILIATION
Audit date (client): November 13, 2026
Ordinary chat and local computation. No Deep Research.

RESULT
56/56 selected engineering values match exactly under the Boeing conversions,
plus 4/4 raw/CSV frame-counter joins. The comparison uses 76 qualified raw
words in aircraft frames 200, 700, 1300 and 1301.

The raw-only ordering gate passes for complete compressed counters 49176-50473
(aircraft frame counters 4-1301). It bridges actual native ARINC sync words to
the final compressed section using physical adjacency and frame/cycle
continuity. It does not count synthesized sync words.

The literal TXT pressure-altitude sum mismatches 14/16 selected pressure
cells, by +128, +256 or +384 feet. All 16 match Boeing Note 3C. All eight
barometer words match recorded-count/100 and have invalid literal BCD
nibbles. These are conversion comparisons, not evidence of an erroneous
export or proof of the historical RAPS implementation.

INPUT
Flight77_Reproducible_Audit_2026-11-12.zip
Actual bytes: 55,468,480
SHA-256:
528cdb88a2010a66af9fd6f30ddfb6b048a49b0b1da15f2c754e079ffa5fc442
Library ID: libfile_9afb870a0e8c81919153b878881eb102
https://chatgpt.com/library?file_id=libfile_9afb870a0e8c81919153b878881eb102&account_id=personal

Exact members under Flight77_Audit/sources/:
American_77.fdr (25,165,994 bytes)
18ad30f72f3d30e5958480252469a1780b51469c903a18c47761ed41fb3ac0f6
AAL77_tabular.csv (19,618,136 bytes)
70740505826cf97b4fd376a8c225f78c87b7b245f46a4dbbd44ce8c356631138
757-3b_1.TXT (656,359 bytes)
374b269812aece0ad75f182f7864a324cadef04e735ebb296ad8b0ebba107e64

REPRODUCTION
Extract this audit ZIP to a directory. Python 3 and a C++17 compiler (g++)
are required. Use an empty work directory. Allow about 1 GB temporary disk.

python3 run_audit.py /path/Flight77_Reproducible_Audit_2026-11-12.zip \
  --work-dir /path/empty-r21-workdir

The runner validates input hashes, compiles the C++ probes, scans native
sync, decodes raw frames, executes the independent Python raw reference and
ordering gate, and only then compares the selected CSV cells. A failed
hash or gate stops the numeric comparison. No network is required.

A fresh end-to-end execution of this runner completed in this audit.
Comparisons, qualified words, complete selected-word ancestry, joins and
the summary reproduced byte-for-byte; ordering-gate JSON was also equal.
See reproduction_check.json.

No author executable is distributed or run. Original source packages and
manufacturer documents are identified by retrieval URLs and hashes in the
source manifests. The author source package was recovered and independently
hash-verified; these supplied audit implementations are distinct software.
For a reproduction without author source bytes, the reference reports that
source fingerprint as unavailable rather than claiming to verify it.

PACKAGE MAP
R21_Raw_Word_Reconciliation_2026-11-13.pdf
  Eight-page technical report: exact inputs, codebook, chronology, sync
  bridge, conversion results, worked bit locators, limits and go/no-go.
R21_Raw_Word_Reconciliation_2026-11-13.txt
  Plain-text counterpart.
run_audit.py
  Single reproduction entry point.
r21_sync_probe.cpp / r21_decode_probe.cpp
  Source-derived native-sync and instrumented raw-word diagnostics.
r21_reconcile.py / comparison_plan.json
  Predefined selection, exact comparisons and raw-bit ancestry replay.
agent_conversion/
  Independently written Python raw reference, final-segment gate and final
  selected-word review; corresponding executed JSON results.
reconciliation/
  comparisons.csv/json: all 60 cell checks, including the four join keys.
  raw_words.json: all 76 qualified decoded words and current-code locators.
  raw_word_lineage.jsonl: baseline and all delta symbols for each word.
  joins.json and summary.json: join evidence and scoped results.
native_sync_probe.jsonl / final_segment_frame_index.jsonl
  Native-sync candidates and the bounded complete-frame index.
decoder_sources/
  Retrieved-source manifest, code fingerprints, source review and direct
  native-transition probe. No vendor/author source archives are republished.
primary_docs/
  Primary document identities, page locators and inspected mappings.
environment.json / input_verification.json / reference_crosscheck.json
  Runtime, code hashes, original-byte checks and cross-implementation vectors.
SHA256SUMS.txt
  Hashes of all package members except this checksum file itself.

LOCATORS
Byte offsets, page indices and decoder record IDs are zero-based. ARINC
subframe, word and channel bit numbers are one-based, with bit 1 the LSB.
Physical file bit addresses use explicit LSB0 within the actual byte.
Compressed word index = (subframe - 1)*255 + word - 2.

A compressed symbol locator is not a direct 12-bit word location. The word
must be reconstructed through its saved baseline/delta ancestry. All 76
ancestries were replayed from the actual encoded bits.

CSV cell rows are physical one-based file lines; columns use standard
spreadsheet letters. The input CSV has no SYNC WORD column. SF1 is joined
by its frame-counter cell; the other subframes follow at 8-row intervals.
The counter joins are separate from the 56 engineering-value checks.
Displayed time strings remain export labels, not independently established
aircraft-clock or event-time readings.

UPDATED GO / NO-GO
GO: verified decoder source, bounded ordering and the selected raw/export
comparison are complete. The former zero-matched-word gate is resolved for
these 76 qualified words and 56 engineering values.

NO-GO: full-capture/full-CSV equivalence, earlier segments, partial terminal
counter 50474, Hamming/parity integrity, historical RAPS behavior,
aircraft-specific door wiring/state, radio-height calibration, impact time,
trajectory and suppression are not established.
