#!/usr/bin/env python3
"""Bounded raw-word to engineering-cell comparison after a passed raw-only gate."""
from pathlib import Path
from decimal import Decimal
import argparse, csv, hashlib, json, struct

HASHES = {
 'American_77.fdr':'18ad30f72f3d30e5958480252469a1780b51469c903a18c47761ed41fb3ac0f6',
 'AAL77_tabular.csv':'70740505826cf97b4fd376a8c225f78c87b7b245f46a4dbbd44ce8c356631138',
 '757-3b_1.TXT':'374b269812aece0ad75f182f7864a324cadef04e735ebb296ad8b0ebba107e64'}
CATS=[('0',0,0),('10',1,2),('110',3,3),('1110',7,4),('111100',15,5),
 ('1111100',31,6),('1111010',63,7),('111111',127,8),('1111101',255,9),
 ('11110110',511,10),('111101110',1023,11),('1111011110',2047,2),('1111011111',-1,0)]

def dump(path,obj):
    path.write_text(json.dumps(obj,indent=2)+'\n')

def signed10(v):
    return (v^512)-512

def huffman(code):
    for p,a,n in CATS:
        if code.startswith(p) and len(code)==len(p)+n:
            if not n:return a
            s=int(code[len(p):],2);h=1<<(n-1);m=s&(h-1)
            return 4096-a-m if s&h else a+m
    raise ValueError(('not an exact codeword',code))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--work-dir',type=Path,default=Path(__file__).resolve().parent)
    a=ap.parse_args();root=a.work_dir
    src=root/'extracted/Flight77_Audit/sources'
    for name,expected in HASHES.items():
        actual=hashlib.sha256((src/name).read_bytes()).hexdigest()
        if actual!=expected:raise RuntimeError(f'Input hash mismatch: {name}')
    gate=json.loads((root/'agent_conversion/final_segment_gate.json').read_text())
    if gate['verdict']!='SCOPED_GO':raise RuntimeError('Raw ordering gate did not pass')
    plan=json.loads((root/'comparison_plan.json').read_text())
    selected=plan['selected_raw_aircraft_frame_counters']
    raw=(src/'American_77.fdr').read_bytes()
    with (src/'AAL77_tabular.csv').open(encoding='cp1252',newline='') as f:
        reader=csv.reader(f);export=[];physical=[]
        for row in reader:export.append(row);physical.append(reader.line_num)
    assert physical==list(range(1,len(export)+1)), 'CSV multiline record changes row coordinates'
    meta={s:[json.loads(l) for l in (root/f'decode_s{s}.jsonl').read_text().splitlines()] for s in (0,1)}
    pages={}
    for s in (0,1):
        pages[s]=[]
        for bank in range(s*512,195584,1024):
            for lp in range(bank+2,min(bank+512,195584)):
                pp=(lp+30720)%196608;fo=170+128*pp
                if raw[fo:fo+128]!=b'\xff'*128:pages[s].append((lp,pp,fo))
    def coordinate(s,p):
        lp,pp,fo=pages[s][p//1013];b=p%1013;n=15-b%16
        return {'stream_bit_index':p,'logical_128byte_page':lp,'physical_128byte_page':pp,
          'page_data_bit':b,'file_byte_offset':fo+2*(b//16)+(n>=8),'bit_in_byte_lsb0':n%8}
    def encoded(s,start,end):
        code=''
        for p in range(start,end):
            c=coordinate(s,p);code+=str((raw[c['file_byte_offset']]>>c['bit_in_byte_lsb0'])&1)
        return code
    words={s:open(root/f'decode_s{s}.words','rb') for s in (0,1)}
    traces={s:open(root/f'decode_s{s}.trace','rb') for s in (0,1)}
    def value(s,rec,i):
        words[s].seek(rec*2040+i*2);return struct.unpack('<H',words[s].read(2))[0]
    def code_offsets(s,rec,i):
        traces[s].seek((rec*1020+i)*16);return struct.unpack('<QQ',traces[s].read(16))
    word_records={};lineage_records={};comparisons=[]
    def obtain(s,rec,sf,word):
        key=f'S{s}:R{rec}:SF{sf}:W{word}'
        if key in word_records:return key
        i=(sf-1)*255+word-2;row=meta[s][rec]
        base=max(r['record'] for r in meta[s][:rec+1] if r['baseline'] and r['compressed'] and
          r['chain_known'] and r['completed_words']==1020 and not r['padding_bad'] and
          not r['sync_lost'] and not r['terminal'])
        acc=0;chain=[]
        for r in meta[s][base:rec+1]:
            assert r['compressed'] and r['completed_words']==1020 and not r['padding_bad'] and not r['sync_lost'] and not r['terminal']
            start,end=code_offsets(s,r['record'],i)
            code=encoded(s,start,end);delta=huffman(code);assert delta>=0
            acc=((0 if r['baseline'] else acc)+delta)&4095
            assert acc==value(s,r['record'],i)
            chain.append({'record':r['record'],'compressed_counter':r['counter'],
              'baseline':r['baseline'],'huffman_code':code,'difference12':delta,
              'decoded_value':acc,'first_bit':coordinate(s,start),
              'last_bit':coordinate(s,end-1)})
        v=value(s,rec,i);assert acc==v
        start,end=code_offsets(s,rec,i)
        word_records[key]={'key':key,'raw_sha256':HASHES['American_77.fdr'],'stream':s,
          'decoder_record':rec,'compressed_counter':row['counter'],
          'aircraft_frame_counter':row['raw_sf1_w256'],'subframe':sf,'word':word,
          'word_value_decimal':v,'word_value_hex':f'{v:03X}','word_bits_msb_to_lsb':f'{v:012b}',
          'last_baseline_record':base,'last_baseline_compressed_counter':meta[s][base]['counter'],
          'ancestry_entries':len(chain),'current_codeword':encoded(s,start,end),
          'current_codeword_first_bit':coordinate(s,start),'current_codeword_last_bit':coordinate(s,end-1),
          'derived_vector_byte_offset':rec*2040+i*2,'lineage_key':key}
        lineage_records[key]={'word_key':key,'baseline_through_selected_delta':chain}
        return key
    joins=[]
    for fc in selected:
        candidates=[r for s in (0,1) for r in meta[s] if r['raw_sf1_w256']==fc and
          49176<=r['counter']<=50473 and r['compressed'] and not r['baseline'] and
          r['chain_known'] and r['completed_words']==1020 and not r['padding_bad'] and not r['sync_lost'] and not r['terminal']]
        assert len(candidates)==1,(fc,len(candidates))
        r=candidates[0];s=r['stream'];rec=r['record']
        cells=[n for n,row in enumerate(export,1) if n>=14 and len(row)>185 and row[185].strip()==str(fc)]
        assert len(cells)==1,(fc,cells)
        row1=cells[0]
        if fc<1301:assert export[row1-1+32][185].strip()==str(fc+1)
        joins.append({'aircraft_frame_counter':fc,'stream':s,'decoder_record':rec,'compressed_counter':r['counter'],
          'csv_sf1_row':row1,'csv_counter_cell':f'GD{row1}','csv_sf1_label':export[row1-1][0],
          'join_basis':'Exact raw/CSV counter join, separate from tested engineering values; SF1 address from Boeing'})
        for sf in (1,2,3,4):
            csvrow=row1+8*(sf-1);cr=export[csvrow-1];assert cr[0].strip()
            for spec in plan['channels']:
                if sf not in spec['sf']:continue
                ks=[obtain(s,rec,sf,w)for w in spec['words']]
                vs=[word_records[k]['word_value_decimal']for k in ks]
                name=spec['name'];alt=None;alt_status=None
                if name=='pressure_altitude':
                    coarse=signed10((vs[0]>>2)&1023);fine=(vs[1]>>2)&127
                    calc=Decimal(128*coarse+fine)
                    alt=Decimal(128*coarse+signed10((vs[1]>>2)&1023))
                elif name=='computed_airspeed':calc=Decimal((vs[0]>>2)&1023)/2
                elif name=='true_airspeed':calc=Decimal(2*((vs[0]>>2)&1023))
                elif name in ('baro_1','baro_2'):
                    calc=Decimal(vs[0])/100
                    digits=[(vs[0]>>k)&15 for k in (8,4,0)]
                    alt_status='valid_BCD_digits_scale_unestablished' if all(d<=9 for d in digits) else 'invalid_BCD_digits'
                else:calc=Decimal(vs[0])
                col=spec['csv_column'];colnum=0
                for ch in col:colnum=colnum*26+ord(ch)-64
                cell=cr[colnum-1].strip()
                actual=Decimal(cell) if cell else None
                comparisons.append({'channel':name,'aircraft_frame_counter':fc,'stream':s,
                  'decoder_record':rec,'compressed_counter':r['counter'],'subframe':sf,
                  'words':spec['words'],'bits':spec['bits'],'word_keys':ks,'raw_values':vs,
                  'csv_sha256':HASHES['AAL77_tabular.csv'],'csv_physical_row':csvrow,
                  'csv_column_number':colnum,'csv_column_letter':col,'csv_cell':col+str(csvrow),
                  'csv_time_label':cr[0],'csv_text':cell,'conversion':spec['primary_formula'],
                  'calculated_value':str(calc),'match':actual==calc if actual is not None else None,
                  'calculated_minus_csv':str(calc-actual) if actual is not None else None,
                  'alternative_formula':spec.get('alternative_formula'),
                  'alternative_value':str(alt) if alt is not None else None,
                  'alternative_minus_csv':str(alt-actual) if alt is not None and actual is not None else None,
                  'alternative_match':alt==actual if alt is not None and actual is not None else None,
                  'alternative_status':alt_status})
    for f in list(words.values())+list(traces.values()):f.close()
    output=root/'reconciliation';output.mkdir(exist_ok=True)
    dump(output/'joins.json',joins)
    dump(output/'comparisons.json',comparisons)
    dump(output/'raw_words.json',list(word_records.values()))
    with (output/'raw_word_lineage.jsonl').open('w')as f:
        for v in lineage_records.values():f.write(json.dumps(v)+'\n')
    fields=[k for k in comparisons[0] if k not in ('word_keys',)]
    with (output/'comparisons.csv').open('w',newline='')as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in comparisons:w.writerow({k:json.dumps(r[k]) if isinstance(r[k],list)else r[k] for k in fields})
    pressure=[r for r in comparisons if r['channel']=='pressure_altitude']
    baro=[r for r in comparisons if r['channel'].startswith('baro_')]
    summary={'ordering_gate':'SCOPED_GO','selected_aircraft_frame_counters':selected,
      'total_cell_comparisons':len(comparisons),
      'engineering_cell_comparisons':sum(r['channel']!='aircraft_frame_counter'for r in comparisons),
      'engineering_matches':sum(r['match'] is True and r['channel']!='aircraft_frame_counter'for r in comparisons),
      'engineering_mismatches':sum(r['match'] is False and r['channel']!='aircraft_frame_counter'for r in comparisons),
      'frame_counter_joins':sum(r['channel']=='aircraft_frame_counter'for r in comparisons),
      'frame_counter_join_matches':sum(r['match'] is True and r['channel']=='aircraft_frame_counter'for r in comparisons),
      'missing_cells':sum(r['match'] is None for r in comparisons),
      'distinct_qualified_raw_words':len(word_records),
      'pressure_literal_TXT_matches':sum(r['alternative_match']is True for r in pressure),
      'pressure_literal_TXT_mismatches':sum(r['alternative_match']is False for r in pressure),
      'baro_literal_BCD_invalid_codes':sum(r['alternative_status']=='invalid_BCD_digits'for r in baro),
      'ancestry_replays_verified':len(lineage_records),
      'scope':'The selected cells only; no historical RAPS or aircraft-state inference.'}
    dump(output/'summary.json',summary)
    print(json.dumps(summary,indent=2))
    for r in pressure:print(json.dumps({k:r[k]for k in ['csv_cell','csv_time_label','raw_values','calculated_value','csv_text','alternative_value','alternative_minus_csv']}))
    for r in baro:print(json.dumps({k:r[k]for k in ['csv_cell','csv_time_label','raw_values','calculated_value','csv_text','alternative_status']}))

if __name__=='__main__':main()
