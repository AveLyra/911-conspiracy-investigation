// Instrumented, independently expressed C++ implementation of the inspected
// Stutt source algorithm. It preserves baseline words rather than synthesizing
// sync words. Output is a diagnostic, not an authenticated RAPS reproduction.
#define main native_probe_entry_unused
#include "r21_sync_probe.cpp"
#undef main
#include <algorithm>
#include <iomanip>
#include <map>
#include <sstream>

struct Node { int child[2]={-1,-1}; int value=-99999; };
static std::vector<Node> codebook() {
 std::vector<Node> t(1);
 struct Cat {const char*prefix;int base,width;};
 const Cat cats[]={{"0",0,0},{"10",1,2},{"110",3,3},{"1110",7,4},
  {"111100",15,5},{"1111100",31,6},{"1111010",63,7},{"111111",127,8},
  {"1111101",255,9},{"11110110",511,10},{"111101110",1023,11},
  {"1111011110",2047,2},{"1111011111",-1,0}};
 for(const auto&c:cats)for(int suffix=0;suffix<(1<<c.width);++suffix) {
  std::string code=c.prefix;
  for(int k=c.width-1;k>=0;--k)code+=char('0'+((suffix>>k)&1));
  int v=c.base;
  if(c.width) {
   int half=1<<(c.width-1),mag=suffix&(half-1);
   v=(suffix&half)?4096-c.base-mag:c.base+mag;
  }
  int n=0;
  for(char ch:code) {
   int b=ch-'0',next=t[n].child[b];
   if(next<0){next=t.size();t[n].child[b]=next;t.push_back(Node{});}
   n=next;
  }
  if(t[n].value!=-99999)throw std::runtime_error("duplicate Huffman code");
  t[n].value=v;
 }
 return t;
}
struct Parsed {
 uint64_t id=0,start=0,end=0,marker=0;
 int counter=-1,completed=0,author_terminal_count=0;
 bool baseline=false,compressed=false,has_marker=false,padding_bad=false;
 bool sync_lost=false,terminal=false,chain_known=false;
 std::array<uint16_t,1020> words{};
 std::array<uint64_t,1020> code_start{},code_end{};
};
class Decoder {
 const Stream&s;
 const std::vector<Node>&tree;
 std::array<uint16_t,1020> previous{};
 uint64_t p=0,next_id=0;
 int counter=-1;
 bool baseline_known=false;
 bool marker_at(uint64_t x) const {
  int inpage=x%1013;
  if(inpage%16 || inpage/16==63 || x+16>s.bits.size())return false;
  int w=0;
  for(int j=0;j<16;++j)w=(w<<1)|s.bits[x+j];
  return w==0xfefe;
 }
 int take(int n) {
  if(p+uint64_t(n)>s.bits.size())throw std::out_of_range("end of bitstream");
  int v=0;while(n--)v=(v<<1)|s.bits[p++];return v;
 }
public:
 Decoder(const Stream&ss,const std::vector<Node>&tt):s(ss),tree(tt){}
 bool done()const{return p>=s.bits.size();}
 Parsed next() {
  Parsed f;f.id=next_id++;f.start=p;f.words=previous;int last_zero=-1;
  try {
   f.baseline=take(1)==1;
   if(f.baseline){
    if(take(3)==0){f.compressed=true;counter=take(16);}
   }else{f.compressed=true;counter+=2;}
   f.counter=counter;
   if(f.compressed) {
    for(int i=0;i<1020;++i) {
     int n=0;f.code_start[i]=p;
     while(tree[n].value==-99999) {
      int b=take(1);if(b==0)last_zero=i;
      n=tree[n].child[b];
      if(n<0)throw std::runtime_error("invalid Huffman traversal");
     }
     int v=tree[n].value;
     if(v<0){f.sync_lost=true;break;}
     f.words[i]=uint16_t(((f.baseline?0:previous[i])+v)&4095);
     f.code_end[i]=p;++f.completed;
    }
   }
   // A delimiter is recognized at a new 16-bit word boundary only after
   // the frame is complete, unsupported, or has a sync-loss symbol.
   while(p<s.bits.size()) {
    if(marker_at(p)){f.has_marker=true;f.marker=p;p+=16;break;}
    if(s.bits[p++]!=1)f.padding_bad=true;
   }
  }catch(const std::out_of_range&){ /* explicit terminal partial code */ }
  f.end=p;f.terminal=!f.has_marker;
  f.author_terminal_count=f.terminal?last_zero+1:f.completed;
  if(f.baseline && f.compressed && f.completed==1020 &&
     !f.padding_bad&&!f.sync_lost&&f.has_marker)baseline_known=true;
  f.chain_known=baseline_known;
  previous=f.words;
  if(f.sync_lost||!f.compressed)baseline_known=false;
  return f;
 }
};
static void build_stream(const std::vector<uint8_t>&raw,uint64_t offset,
 uint64_t startpage,uint64_t pagecount,int st,Stream&s) {
 uint64_t limit=pagecount-1024;
 for(uint64_t bank=st*512;bank<limit;bank+=1024)
  for(uint64_t lp=bank+2;lp<bank+512&&lp<limit;++lp) {
   uint64_t pp=(lp+startpage)%pagecount,fo=offset+pp*128;
   bool empty=true;
   for(int k=0;k<128;++k)if(raw.at(fo+k)!=255){empty=false;break;}
   if(empty){++s.omitted_empty_pages;continue;}
   s.pages.push_back({uint32_t(lp),uint32_t(pp),fo});
   for(int k=0;k<1013;++k)s.bits.push_back((word_at(raw,fo+2*(k/16))>>(15-k%16))&1);
  }
}
static void emit_frame(std::ostream&out,const Stream&s,int st,const Parsed&f) {
 out<<"{\"stream\":"<<st<<",\"record\":"<<f.id<<",\"counter\":"<<f.counter
    <<",\"baseline\":"<<(f.baseline?"true":"false")
    <<",\"compressed\":"<<(f.compressed?"true":"false")
    <<",\"completed_words\":"<<f.completed
    <<",\"chain_known\":"<<(f.chain_known?"true":"false")
    <<",\"padding_bad\":"<<(f.padding_bad?"true":"false")
    <<",\"sync_lost\":"<<(f.sync_lost?"true":"false")
    <<",\"terminal\":"<<(f.terminal?"true":"false")
    <<",\"author_terminal_count\":"<<f.author_terminal_count
    <<",\"start_bit\":"<<f.start<<",\"end_bit_exclusive\":"<<f.end
    <<",\"start_locator\":";
 locator(out,s,f.start);
 out<<",\"raw_sf1_w256\":"<<f.words[254]<<",\"raw_sf3_w256\":"<<f.words[764]
    <<"}\n";
}
int main(int argc,char**argv) {
 try {
  if(argc!=3)throw std::runtime_error("usage: decode_probe raw.fdr output_prefix");
  std::ifstream in(argv[1],std::ios::binary);
  if(!in)throw std::runtime_error("cannot open raw");
  std::vector<uint8_t>raw((std::istreambuf_iterator<char>(in)),{});
  uint64_t offset=0,start=0;
  for(int64_t fp=int64_t(raw.size())-131072;fp>=0;fp-=131072) {
   auto w=word_at(raw,fp);
   if(w==0xfe6b)offset=fp;
   else if(w==0xffff){offset=fp;start=fp+131072;}
   else break;
  }
  if(start>=raw.size())start=offset;
  uint64_t pagecount=(raw.size()-offset)/128,startpage=(start-offset)/128;
  const auto tree=codebook();
  for(int st=0;st<2;++st) {
   Stream s;build_stream(raw,offset,startpage,pagecount,st,s);
   std::string prefix=std::string(argv[2])+"_s"+std::to_string(st);
   std::ofstream meta(prefix+".jsonl"),words(prefix+".words",std::ios::binary);
   std::ofstream traces(prefix+".trace",std::ios::binary);
   std::ofstream native(prefix+".native.jsonl");
   Decoder d(s,tree);
   std::vector<Parsed> baselines;
   while(!d.done()) {
    auto f=d.next();
    emit_frame(meta,s,st,f);
    for(auto w:f.words){words.put(w&255);words.put(w>>8);}
    // Two uint64 LE stream-bit offsets for each compressed symbol.
    for(int i=0;i<1020;++i)for(auto v:{f.code_start[i],f.code_end[i]})
      for(int k=0;k<8;++k)traces.put((v>>(8*k))&255);
    if(f.baseline&&f.compressed&&f.completed==1020&&!f.padding_bad&&!f.sync_lost&&f.has_marker)
      baselines.push_back(f);
   }
   // Native candidates use actually stored 12-bit sync words. Compare them
   // to neighboring full baselines only; no synthesized W1 is tested.
   const std::array<int,4> sync={0x247,0x5b8,0xa47,0xdb8};
   int rolling=0;
   for(uint64_t end=0;end<s.bits.size();++end) {
    rolling=(rolling>>1)|(int(s.bits[end])<<11);
    if(end<11)continue;
    int sf=-1;for(int j=0;j<4;++j)if(rolling==sync[j])sf=j;
    if(sf<0)continue;
    uint64_t p=end-11;
    if(p>=3072&&native_word(s,p-3072)==sync[(sf+3)%4])continue;
    int n=1;
    while(p+uint64_t(n)*3072+12<=s.bits.size()&&native_word(s,p+uint64_t(n)*3072)==sync[(sf+n)%4])++n;
    if(n<3)continue;
    auto next=std::lower_bound(baselines.begin(),baselines.end(),p,
      [](const Parsed&f,uint64_t bit){return f.start<bit;});
    std::vector<const Parsed*>near;
    if(next!=baselines.end())near.push_back(&*next);
    if(next!=baselines.begin())near.push_back(&*(next-1));
    for(const auto*f:near) {
     native<<"{\"stream\":"<<st<<",\"native_start_bit\":"<<p<<",\"first_subframe\":"<<sf+1
           <<",\"native_sync_count\":"<<n<<",\"baseline_record\":"<<f->id
           <<",\"baseline_counter\":"<<f->counter<<",\"baseline_start_bit\":"<<f->start
           <<",\"subframe_comparisons\":[";
     for(int j=0;j<n-1;++j) {
      if(j)native<<",";
      int sfj=(sf+j)%4;
      int eq=0;
      for(int w=2;w<=256;++w)if(native_word(s,p+uint64_t(j)*3072+12*(w-1))==f->words[sfj*255+w-2])++eq;
      native<<"{\"sf\":"<<sfj+1<<",\"same_words\":"<<eq<<",\"compared_words\":255}";
     }
     native<<"]}\n";
    }
   }
  }
  return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
}
