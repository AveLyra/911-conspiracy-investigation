#!/usr/bin/env python3
"""Reproduce the bounded R21 audit from the exact original source archive."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, zipfile

ARCHIVE_HASH='528cdb88a2010a66af9fd6f30ddfb6b048a49b0b1da15f2c754e079ffa5fc442'
MEMBERS={
 'American_77.fdr':'18ad30f72f3d30e5958480252469a1780b51469c903a18c47761ed41fb3ac0f6',
 'AAL77_tabular.csv':'70740505826cf97b4fd376a8c225f78c87b7b245f46a4dbbd44ce8c356631138',
 '757-3b_1.TXT':'374b269812aece0ad75f182f7864a324cadef04e735ebb296ad8b0ebba107e64'}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('archive',type=Path)
    p.add_argument('--work-dir',type=Path,required=True)
    a=p.parse_args();src=Path(__file__).resolve().parent;root=a.work_dir.resolve()
    if root.exists() and any(root.iterdir()):
        raise SystemExit('Use an empty --work-dir to keep this reproduction isolated.')
    root.mkdir(parents=True,exist_ok=True)
    zbytes=a.archive.read_bytes()
    if len(zbytes)!=55468480 or hashlib.sha256(zbytes).hexdigest()!=ARCHIVE_HASH:
        raise SystemExit('Archive size or SHA-256 mismatch; stopped before decoding.')
    target=root/'extracted/Flight77_Audit/sources';target.mkdir(parents=True)
    verify={'archive_size_bytes':len(zbytes),'archive_sha256':ARCHIVE_HASH,'members':[]}
    with zipfile.ZipFile(a.archive) as z:
        for name,h in MEMBERS.items():
            b=z.read('Flight77_Audit/sources/'+name)
            if hashlib.sha256(b).hexdigest()!=h:raise SystemExit('Member hash mismatch: '+name)
            (target/name).write_bytes(b)
            verify['members'].append({'name':name,'size_bytes':len(b),'sha256':h})
    (root/'input_verification.json').write_text(json.dumps(verify,indent=2)+'\n')
    shutil.copyfile(src/'comparison_plan.json',root/'comparison_plan.json')
    (root/'agent_conversion').mkdir()
    env=dict(os.environ,R21_WORK_DIR=str(root))
    def run(argv,log):
        with (root/log).open('w')as out:
            subprocess.run([str(x)for x in argv],check=True,env=env,stdout=out,stderr=subprocess.STDOUT)
    for name in ['r21_sync_probe','r21_decode_probe']:
        run(['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror',src/(name+'.cpp'),'-o',root/name],name+'_build.log')
    run([root/'r21_sync_probe',target/'American_77.fdr',root/'native_sync_probe.jsonl'],'native_sync.log')
    run([root/'r21_decode_probe',target/'American_77.fdr',root/'decode'],'decoder.log')
    run([sys.executable,src/'agent_conversion/first_frames_reference.py'],'first_reference.log')
    run([sys.executable,src/'agent_conversion/final_segment_gate.py'],'ordering_gate.log')
    gate=json.loads((root/'agent_conversion/final_segment_gate.json').read_text())
    if gate['verdict']!='SCOPED_GO':raise SystemExit('Raw ordering gate failed; no engineering comparison.')
    run([sys.executable,src/'r21_reconcile.py','--work-dir',root],'reconciliation.log')
    summary=json.loads((root/'reconciliation/summary.json').read_text())
    print(json.dumps(summary,indent=2))
    if summary['engineering_mismatches'] or summary['missing_cells'] or summary['frame_counter_join_matches']!=4:
        raise SystemExit('Completed with discrepancies; inspect the comparison records.')
    print('Results:',root/'reconciliation')

if __name__=='__main__':main()
