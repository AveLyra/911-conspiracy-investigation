#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>
// Source-informed native-sync diagnostic. No engineering CSV is opened.
struct Page { uint32_t logical, physical; uint64_t offset; };
struct Stream {
  std::vector<uint8_t> bits;
  std::vector<Page> pages;
  uint64_t omitted_empty_pages = 0;
};
static uint16_t word_at(const std::vector<uint8_t>& b, size_t p) {
  return uint16_t(b.at(p)) | (uint16_t(b.at(p+1)) << 8);
}
static int native_word(const Stream& s, uint64_t p) {
  int v=0;
  for(int k=0;k<12;++k) v |= int(s.bits.at(p+k)) << k;
  return v;
}
static void locator(std::ostream& o,const Stream& s,uint64_t p) {
  const auto &pg=s.pages.at(p/1013);
  int b=p%1013, numbit=15-(b%16);
  uint64_t byte=pg.offset+2*(b/16)+(numbit>=8?1:0);
  o << "{\"logical_128byte_page\":"<<pg.logical
    <<",\"physical_128byte_page\":"<<pg.physical
    <<",\"page_data_bit\":"<<b
    <<",\"file_byte_offset\":"<<byte
    <<",\"bit_in_byte_lsb0\":"<<(numbit%8)<<"}";
}
int main(int argc,char**argv) {
 try {
  if(argc!=3) throw std::runtime_error("usage: sync_probe raw.fdr output.jsonl");
  std::ifstream f(argv[1],std::ios::binary);
  if(!f) throw std::runtime_error("cannot open raw input");
  std::vector<uint8_t> raw((std::istreambuf_iterator<char>(f)),{});
  const uint64_t pairbytes=131072, pagebytes=128;
  uint64_t offset=0,start=0;
  for(int64_t fp=int64_t(raw.size())-pairbytes;fp>=0;fp-=pairbytes) {
   auto w=word_at(raw,fp);
   if(w==0xfe6b) offset=fp;
   else if(w==0xffff) { offset=fp; start=fp+pairbytes; }
   else break;
  }
  if(start>=raw.size())start=offset;
  const uint64_t pagecount=(raw.size()-offset)/128;
  const uint64_t startpage=(start-offset)/128, limit=pagecount-1024;
  if((raw.size()-offset)%128 || startpage>=pagecount)throw std::runtime_error("page geometry");
  std::ofstream out(argv[2]);
  out << "{\"kind\":\"geometry\",\"payload_offset\":"<<offset
      <<",\"ring_start_physical_page\":"<<startpage
      <<",\"logical_page_limit\":"<<limit<<"}\n";
  const std::array<int,4> sync={0x247,0x5b8,0xa47,0xdb8};
  for(int st=0;st<2;++st) {
   Stream s;
   s.bits.reserve(100000000);
   for(uint64_t block=st*512;block<limit;block+=1024) {
    for(uint64_t lp=block+2;lp<block+512&&lp<limit;++lp) {
     uint64_t pp=(lp+startpage)%pagecount, fo=offset+pp*pagebytes;
     bool empty=true;
     for(int k=0;k<128;++k)if(raw.at(fo+k)!=255){empty=false;break;}
     if(empty){++s.omitted_empty_pages;continue;}
     s.pages.push_back({uint32_t(lp),uint32_t(pp),fo});
     for(int k=0;k<1013;++k)s.bits.push_back((word_at(raw,fo+2*(k/16))>>(15-k%16))&1);
    }
   }
   out<<"{\"kind\":\"stream\",\"stream\":"<<st<<",\"pages\":"<<s.pages.size()
      <<",\"bits\":"<<s.bits.size()<<",\"omitted_empty_pages\":"<<s.omitted_empty_pages<<"}\n";
   int rolling=0;
   for(uint64_t end=0;end<s.bits.size();++end) {
    rolling=(rolling>>1)|(int(s.bits[end])<<11);
    if(end<11)continue;
    int sf=-1;
    for(int j=0;j<4;++j)if(rolling==sync[j])sf=j;
    if(sf<0)continue;
    uint64_t p=end-11;
    if(p>=3072 && native_word(s,p-3072)==sync[(sf+3)%4])continue;
    int n=1;
    while(p+uint64_t(n)*3072+12<=s.bits.size()&&native_word(s,p+uint64_t(n)*3072)==sync[(sf+n)%4])++n;
    if(n<2)continue;
    out<<"{\"kind\":\"native_sync_candidate\",\"stream\":"<<st
       <<",\"start_stream_bit\":"<<p<<",\"first_subframe\":"<<(sf+1)
       <<",\"consecutive_syncs\":"<<n<<",\"syncs\":[";
    for(int j=0;j<n;++j){if(j)out<<",";out<<sync[(sf+j)%4];}
    out<<"],\"sync_locators\":[";
    for(int j=0;j<n;++j){if(j)out<<",";locator(out,s,p+uint64_t(j)*3072);}
    out<<"],\"observed_word2_3\":[";
    for(int j=0;j<n;++j){if(j)out<<",";auto q=p+uint64_t(j)*3072;out<<"["<<native_word(s,q+12)<<","<<native_word(s,q+24)<<"]";}
    out<<"]}\n";
   }
  }
  return 0;
 } catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
}
