#!/usr/bin/env python3
"""Render the R21 audit from the actual comparison and gate outputs."""
from pathlib import Path
import json, hashlib, html, re
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Preformatted
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
P=OUT/'R21_Raw_Word_Reconciliation_2026-11-13.pdf'
rows=json.loads((ROOT/'reconciliation/comparisons.json').read_text())
raw={r['key']:r for r in json.loads((ROOT/'reconciliation/raw_words.json').read_text())}
joins=json.loads((ROOT/'reconciliation/joins.json').read_text())
summary=json.loads((ROOT/'reconciliation/summary.json').read_text())
gate=json.loads((ROOT/'agent_conversion/final_segment_gate.json').read_text())
env=json.loads((ROOT/'environment.json').read_text())
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleR',fontName='Helvetica-Bold',fontSize=24,leading=28,textColor=colors.HexColor('#17334d'),spaceAfter=12))
styles.add(ParagraphStyle(name='H1R',fontName='Helvetica-Bold',fontSize=17,leading=21,textColor=colors.HexColor('#17334d'),spaceAfter=12))
styles.add(ParagraphStyle(name='H2R',fontName='Helvetica-Bold',fontSize=11.5,leading=15,textColor=colors.HexColor('#087e83'),spaceBefore=9,spaceAfter=5))
styles.add(ParagraphStyle(name='BodyR',fontName='Helvetica',fontSize=9.4,leading=13.1,spaceAfter=7))
styles.add(ParagraphStyle(name='SmallR',fontName='Helvetica',fontSize=8,leading=10.5,spaceAfter=5))
styles.add(ParagraphStyle(name='CellR',fontName='Helvetica',fontSize=8,leading=10.2))
styles.add(ParagraphStyle(name='HeadR',fontName='Helvetica-Bold',fontSize=8,leading=10,textColor=colors.white))
styles.add(ParagraphStyle(name='CodeR',fontName='Courier',fontSize=8,leading=11,spaceAfter=8))
story=[];plain=[]
def para(s,sty='BodyR'):
    story.append(Paragraph(s,styles[sty]));plain.append(s)
def title(s):para(s,'H1R')
def sub(s):para(s,'H2R')
def page():story.append(PageBreak());plain.append('\n'+'='*72+'\n')
def table(headers,data,widths):
    vals=[[Paragraph(html.escape(str(c)),styles['HeadR'])for c in headers]]
    vals += [[Paragraph(str(c),styles['CellR'])for c in rr]for rr in data]
    t=Table(vals,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([
      ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#17334d')),
      ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f0f5f7')]),
      ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),
      ('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),
      ('BOTTOMPADDING',(0,0),(-1,-1),5),
      ('LINEBELOW',(0,0),(-1,0),0.5,colors.HexColor('#17334d'))]))
    story.append(t);story.append(Spacer(1,8))
    plain.append(' | '.join(headers))
    plain.extend(' | '.join(str(c).replace('<br/>',' ')for c in rr)for rr in data)
def code(s):
    story.append(Preformatted(s,styles['CodeR']));plain.append(s)
def mono(s):
    return '<font name="Courier" size="7.3">'+s[:32]+'<br/>'+s[32:]+'</font>'

para('Flight 77<br/>Raw words to engineering export','TitleR')
para('Scooby R21 | Next-stage audit | November 13, 2026','SmallR')
para('<b>Result: 56 of 56 selected engineering values match exactly, plus all four frame-counter joins.</b> The comparison uses 76 qualified decoded words in four predefined frames. There are no missing cells or mismatches under the Boeing conversion rules in this sample. The literal database-printout altitude alternative differs in 14 of 16 cases.')
para('The source archive and original members were opened and hash-verified. The exact author decoder source was then recovered. An instrumented C++ implementation and a separately written Python reference established a bounded raw ordering check before any engineering comparison. No Deep Research was started.')
table(['Gate','Result'],[
 ['Archive and named member identity','PASS against actual bytes'],
 ['Native sync and final-segment ordering','SCOPED PASS: 1,298 complete unique frames'],
 ['Selected raw/export comparison','56 engineering matches; 4 counter joins; 0 discrepancies'],
 ['Historical RAPS / aircraft interpretation','NOT established by this computation']
],[180,331])
sub('Exact input bytes')
inputs=json.loads((ROOT/'input_verification.json').read_text())
table(['Input','Bytes / SHA-256'],[
 ['Flight77_Reproducible_Audit_2026-11-12.zip','55,468,480<br/>'+mono(inputs['sha256'])],
 *[[Path(m['name']).name,f"{m['size']:,}<br/>"+mono(m['sha256'])]for m in inputs['members']]
],[180,331])
para('The archive ZIP integrity check passed. Hash agreement establishes identity with the supplied package and claims; it is not independent certification of the original agency disc. Source package Library ID: libfile_9afb870a0e8c81919153b878881eb102. Earlier report: R21_REPORT.md, retrieved and read in full. This audit extends its unresolved decoder gate.','SmallR')

page();title('1. Decoder source and exact coding rule')
para('Author source: Warren Stutt, AAL77FDRDecoder. The recovered ZIP is <b>803,666 bytes</b> and matches the prior SHA-256 claim:')
para(mono('1f2322c484737fcd0263e4d5d8e0862c97da2c74121da883dd4238b443055548'),'SmallR')
para('Main project ApplicationVersion <b>1.10.0.0</b>, target .NET 4.0 / Windows Forms. Assembly/file versions are 1.0.0.0; a backup project identifies 1.7.0.0. The audited main GenerateOutput.cs is 122,031 bytes, SHA-256:')
para(mono('16e2ec3b5968bcbd2d9be67e1f56cccb3b1d4e2ef3b29d3e2a1229c083acee75'),'SmallR')
para('The original executable was not run. The supplied C++ code implements the inspected raw algorithm with explicit provenance and bounded reads. The Python reference independently decodes absolute baselines and selected delta chains. This is a reproducible implementation check, not proof of the historical NTSB RAPS build or configuration.')
sub('Modified-Huffman codebook')
para('For suffix width n &gt; 0, its first bit is sign s and its remaining bits are unsigned magnitude m. With category start a, the unsigned 12-bit difference is a + m when s = 0 and 4096 - a - m when s = 1. A baseline assigns the difference directly; a delta adds it to the preceding same-stream word modulo 4096.')
cats=[('0',0,0),('10',1,2),('110',3,3),('1110',7,4),('111100',15,5),('1111100',31,6),('1111010',63,7),('111111',127,8),('1111101',255,9),('11110110',511,10),('111101110',1023,11),('1111011110',2047,2),('1111011111','sync-loss sentinel -1',0)]
table(['Prefix','Category start a','Suffix width n'],cats,[160,211,140])
para('Special case: prefix 1111011110 with suffixes 00, 01, 10, 11 yields 2047, 2048, 2049, 2048. The repeated 2048 is preserved. The sentinel -1 is distinct from a valid difference of 4095. Source: GenerateOutput.cs lines 1644-1715 and 2115-2128.','SmallR')

page();title('2. Page order, frame boundaries and partial data')
para('Terminology: a <b>page</b> here is 128 bytes; a <b>bank</b> is 64 KiB; a bank pair is 128 KiB. These sizes distinguish hardware pages from the larger envelope units used in earlier summaries.')
sub('Source-derived read order')
para('The reader scans bank-pair headers backward, identifies the erased pair, and starts the ring after it. For these bytes, the payload begins at offset 170 and logical page 0 maps to physical 128-byte page 30,720. Pairs are visited 30 through 191, then 0 through 28; erased pair 29 is excluded. This is an implementation-supported read order, not an independently established wall clock.')
para('Stream 0 takes the first bank of each pair; stream 1 takes the second. The first two 128-byte pages of each bank are skipped. Entirely FF pages are skipped, without inserting zero-valued words. Each retained page contributes 1,013 bits: 16-bit words are loaded little-endian, then consumed most-significant bit first. The last 11 page bits are not used by this decoder.')
sub('Frame state and chronology')
para('A baseline begins with 1000 and a 16-bit compressed-frame counter, followed by 1,020 Huffman-coded words. A delta begins with 0, advances that stream counter by two and updates its preceding frame. The 1,020 words correspond to SF1-SF4, W2-W256; W1 is absent. The stored 16-bit FEFE delimiter is recognized only at a new 16-bit boundary while waiting for an end marker, excluding page word 63. Padding before that delimiter must be all ones.')
para('The author merges streams using the modular comparison ((candidate - current) &amp; 0x8000). This audit validates the final bounded interval directly, where counters run 49176-50473 without a wrap. Periodic baselines duplicate the current frame and are not extra time steps.')
table(['Handling decision','Audit treatment'],[
 ['Baseline suppression','The author suppresses all baselines, including the first in each stream. This audit retains them as evidence, then removes verified periodic duplicates from the merged interval. It does not claim identical GUI output.'],
 ['Unsupported / bad records','All are flagged in diagnostic metadata. The selected interval contains no such records. They are not accepted as engineering observations.'],
 ['End-of-input behavior','Reads are bounded before leaving the eligible ring. The original after-increment bound and unbounded empty-page loop are not copied as unsafe EOF behavior.'],
 ['Partial-frame cutoff','Both completed-symbol count and the original last-zero-bit heuristic are recorded. No uncompleted symbol is promoted to a usable selected word.'],
 ['Partial final frame','Compressed counter 50474 has 1,007 completed words and a sync-loss symbol. It and subsequent unsupported records are excluded from this reconciliation.']
],[130,381])
para('The author ignores bad-page maps and Hamming/parity validation; this audit likewise does not certify those integrity fields. ASC-TRT99-007 figure 4.2-2 supports the general two-stream memory layout, but not this exact codebook or all implementation details. Its apparent data-page label differs from the code start; that ambiguity is retained.','SmallR')

page();title('3. Ordering validated against stored native sync')
para('The compressed decoder does not recover W1 sync words. The author GUI synthesizes a subframe identifier, and the separate decompressor inserts standard sync constants. Testing those inserted values would be circular. This audit instead reads native uncompressed bits immediately before the final segment\'s first baseline.')
para('Manufacturer documentation supplies the expected sequence 0x247, 0x5B8, 0xA47, 0xDB8, with ARINC word bits transmitted LSB first. Those values are actually present at 3,072-bit intervals in the retained page stream. This native word-bit direction is distinct from the recorder storage-bit order. [S3]')
table(['Native subframe','Observed W1','File byte / bit (LSB0)','Logical page / data bit'],[
 ['SF1','0x247','2,783,100 / 1','187629 / 670'],
 ['SF2','0x5B8','2,783,488 / 0','187632 / 703'],
 ['SF3','0xA47','2,783,879 / 7','187635 / 736'],
 ['SF4','0xDB8','2,784,267 / 6','187638 / 769']
],[85,80,176,170])
para('The native SF4 is partial. The next aligned FEFE storage word is at byte 2,784,572. The following actual header begins at byte 2,784,575, bit 7: 1000 plus compressed counter 49176. Its payload starts at byte 2,784,577, bit 3. All offsets are zero-based.')
para('Native SF1 W256 is 3 and native SF3 W256 has cycle nibble 0. The following baseline decodes to raw frame counter 4 and cycle nibble 1. Stream 1 then supplies counter 5 / cycle 2. These primary-document-addressed fields connect the observed native phase to the compressed sequence. This is a local ordering check; the native and following compressed frames are distinct observations, not identical copies.')
table(['Independent or internal check','Observed result'],[
 ['Raw-only scope','Compressed counters 49176-50473; raw aircraft counters 4-1301'],
 ['Unique complete merged frames','1,298; zero missing counters, cycle failures or bad frames'],
 ['Periodic baseline duplicates','17 / 17 identical across all 1,020 words'],
 ['Independent Python absolute baselines','19 / 19 identical to C++, decoded directly from raw bytes'],
 ['Initial cross-implementation checks','Four additional full baseline/delta vectors match: 4,080 words'],
 ['Independent final selected-word replay','50 frames from the last stream-1 baseline; final words and physical encoded-bit endpoints match']
],[210,301])
para('<b>Gate: SCOPED GO.</b> This supports qualified decoded word addresses inside the complete final segment. It does not assert that sync words are stored in every compressed frame, validate earlier segments, or establish absolute timing. The gate JSON was produced before engineering comparisons.')

page();title('4. Pressure-altitude reconciliation')
para('The predefined selection uses raw aircraft frame counters 200, 700, 1300 and 1301. Each joins to the CSV FRAME COUNTER at SF1 W256. Successive main export rows are eight rows apart; blank cells are preserved. The CSV has no SYNC WORD column. No altitude value was used to choose the alignment.')
table(['Raw frame','Stream / record','Compressed counter','CSV SF1 counter cell'],[
 [j['aircraft_frame_counter'],f"{j['stream']} / {j['decoder_record']}",j['compressed_counter'],j['csv_counter_cell']]for j in joins
],[75,140,126,170])
para('Boeing Note 3C excludes W30 bits 10-12 because sign/overlap information is duplicated. Use W29 b3-12 and W30 b3-9. The database printout instead exposes two signed ten-bit components and a literal sum. Both were evaluated on the same actual words. [S1, S2]')
code('Boeing = 128*signed10((W29>>2)&1023) + ((W30>>2)&127)\nTXT    = 128*signed10((W29>>2)&1023) + signed10((W30>>2)&1023)\nsigned10(x) = (x ^ 512) - 512')
prs=[r for r in rows if r['channel']=='pressure_altitude']
table(['Frame / SF','W29 / W30 (decimal)','Boeing = CSV (ft)','CSV cell','Literal TXT (ft)','TXT delta (ft)'],[
 [f"{r['aircraft_frame_counter']} / {r['subframe']}",' / '.join(map(str,r['raw_values'])),r['csv_text'],r['csv_cell'],r['alternative_value'],r['alternative_minus_csv']]for r in prs
],[65,95,91,78,95,87])
para('<b>16 / 16 Boeing matches; 14 / 16 literal TXT mismatches.</b> Differences are +128, +256 or +384 ft in this selection. This discriminates the tested formulas at recorder-word level. It does not demonstrate that historical RAPS executed the literal TXT sum, nor that the export is erroneous.')

page();title('5. Barometer and independent engineering controls')
para('Boeing Note 4C distinguishes the incoming BCD description from the recorded word. The documented recorded count is divided by 100. The tested barometer words agree exactly with their export cells under that rule. All eight have nondecimal nibbles if read as literal three-digit BCD. No undocumented BCD scaling was added. [S1, S2]')
br=[r for r in rows if r['channel'].startswith('baro_')]
table(['Frame / SF','Raw W147 dec / hex','Count / 100 (inHg)','CSV cell','CSV value'],[
 [f"{r['aircraft_frame_counter']} / {r['subframe']}",f"{r['raw_values'][0]} / {r['raw_values'][0]:03X}",r['calculated_value'],r['csv_cell'],r['csv_text']]for r in br
],[80,125,121,95,90])
sub('All tested channels')
table(['Channel and qualified address','Cells','Exact matches'],[
 ['Pressure: all SF, W29 b3-12 + W30 b3-9','16','16'],
 ['Computed airspeed: all SF, W96 b3-12, unsigned / 2','16','16'],
 ['True airspeed: all SF, W212 b3-12, unsigned x 2','16','16'],
 ['Barometer 1/2: SF2/SF4, W147 b1-12, count / 100','8','8'],
 ['Frame counter joins: SF1 W256 b1-12','4','4']
],[351,80,80])
para('The first four rows are <b>56 engineering values</b>; the last row contains <b>four join keys</b>. The keys are not counted as additional independent engineering confirmations. The 60 cell records use 76 distinct qualified raw words, because pressure altitude uses two words per value.')
para('Exact decimal equality was required, with zero numerical tolerance. These sampled conversions fall exactly on the CSV display resolution. No calibration tolerance, interpolation, phase fitting or physical trajectory argument was used.')
sub('Concrete example')
para('At aircraft frame 1301 / SF4, W29 = 0x004 and W30 = 0x2B4. The coarse field is 1; the seven-bit fine field is 45. Boeing therefore gives 128 + 45 = <b>173 ft</b>, exactly CSV <b>E37806</b>. Retaining the overlapping fine bits gives 128 + 173 = <b>301 ft</b>. The 128-ft difference is now demonstrated on decoded words, rather than an inverted export example.')
para('At the same frame / SF4, W147 = 0xBCF = 3023; 3023 / 100 = <b>30.23 inHg</b>, exactly <b>CH37806</b>. Its nibbles B, C, F cannot be literal decimal digits.')

page();title('6. Fully qualified raw and export locators')
para('Raw identity for every key is American_77.fdr SHA-256 18ad30f72f3d30e5958480252469a1780b51469c903a18c47761ed41fb3ac0f6. CSV identity is AAL77_tabular.csv SHA-256 70740505826cf97b4fd376a8c225f78c87b7b245f46a4dbbd44ce8c356631138.')
para('Worked endpoint: <b>stream 1, decoder record 19324, compressed counter 50473, aircraft frame counter 1301, SF4</b>. Its raw vector is reached from baseline record 19275 / compressed counter 50375 through 49 deltas. The package preserves all 50 ancestry entries for each selected word.')
data=[]
for w in [29,30,147]:
 r=raw[f'S1:R19324:SF4:W{w}']
 a,b=r['current_codeword_first_bit'],r['current_codeword_last_bit']
 data.append([f'W{w}<br/>{r["word_value_hex"]} ({r["word_value_decimal"]})',r['current_codeword'],
  f'{a["file_byte_offset"]:,} / {a["bit_in_byte_lsb0"]}<br/>to {b["file_byte_offset"]:,} / {b["bit_in_byte_lsb0"]}',
  f'{a["logical_128byte_page"]} / {a["page_data_bit"]}<br/>to {b["logical_128byte_page"]} / {b["page_data_bit"]}'])
table(['Decoded word','Current Huffman code','First / last actual file byte + bit','Logical page / data bit'],data,[80,141,150,140])
para('<b>These are compressed symbol locations, not direct 12-bit word storage locations.</b> W147 has a zero-difference code at this frame; its value comes from the baseline and intervening deltas. raw_word_lineage.jsonl records each exact code string, unsigned difference, accumulator value, and first/last bit locator. All 76 selected word ancestries were replayed from raw bits and matched the decoded vectors.')
sub('Index conventions')
para('Streams, decoder record IDs, physical file byte offsets and page indices are zero-based. Subframe, word and channel bit numbers are one-based; channel bit 1 is the numeric LSB. File bit locators explicitly use LSB0 within the actual byte. Encoded order crosses storage words, pages and skipped ECC fields, so a start/end pair must be interpreted using the documented page iterator.')
para('For a compressed frame without sync words, the decoded array index is (SF - 1) x 255 + W - 2. CSV cells use one-based physical file rows and standard spreadsheet column letters. Every parsed source CSV record occupies one physical line. Example E37806 means physical line 37806, column 5; CH37806 means the same line, column 86.')
sub('Inspectable package')
para('comparisons.csv and comparisons.json contain all 60 cell checks. raw_words.json contains all 76 full raw keys. joins.json records the four joins. raw_word_lineage.jsonl contains the bit-level ancestry. final_segment_gate.json, reference_crosscheck.json and reconciliation_review.json contain the executed validation results. The accompanying code recreates these records from the original archive.')

page();title('7. Reproduction, limits and updated decision')
sub('Reproduce from the exact source package')
code('python3 run_audit.py /path/Flight77_Reproducible_Audit_2026-11-12.zip \\\n  --work-dir /path/empty-r21-workdir')
para('The runner verifies the archive and all three input hashes, extracts only those members, builds both C++ probes, scans native sync, decodes raw frames, reruns the independent Python reference and ordering gate, then performs the predeclared cell comparisons. A failed hash or ordering gate stops the comparison. It requires Python 3 and a C++17 compiler; no network or author executable is required. Allow roughly 1 GB of temporary disk space for full diagnostic word and trace streams.')
para('Executed environment: Python 3.12.14; g++ (Debian 14.2.0-19) 14.2.0; Linux x86_64, glibc 2.41. Compilation: g++ -std=c++17 -O2 -Wall -Wextra -Werror. Exact platform, source hashes and artifact hashes are in environment.json and SHA256SUMS.txt.')
sub('Primary sources and code locators')
para('<b>S1.</b> Boeing D226A101-3, Rev G, October 27, 1999; 588-page archived mirror, hash verified. Pressure: printed p20 / PDF28 Note 3C and E18 / PDF414. Barometer: pp21-22 / PDF29-30 Note 4C. Counter: E64 / PDF460 and E114 / PDF510. Sync slot: E61 / PDF457 and E66 / PDF462. Exact URL/hash in primary_reference_findings.json.','SmallR')
para('<b>S2.</b> 757-3b_1.TXT, candidate AA database printout, embedded date October 24, 2001. ALT_COA lines 1737-1752; ALT_FIN 1754-1769; PresAlt 14212-14223; BARO_CR1/2 2812-2842; CMPT_ASP 3794-3809; TRUE_ASP 18450-18465. Original input hash on page 1.','SmallR')
para('<b>S3.</b> Alta Data Technologies, ARINC Protocol Summary 10011-00000-A1, Rev A1, April 7, 2010, printed pp15-16 / PDF18-19. <link href="https://www.altadt.com/wp-content/uploads/dlm_uploads/2013/11/ARINC-Protocol-Summary.pdf" color="#087e83">Manufacturer PDF</link>. SHA-256 cd0aa00cd592b130ba16d84cc340a4a5b70cbbcad7f1b02c89449f9ee60c3796.','SmallR')
para('<b>S4.</b> Stutt AAL77FDRDecoder source, <link href="https://web.archive.org/web/20130205114141id_/http://warrenstutt.com/AAL77FDRDecoder/Source/AAL77FDRDecoder.zip" color="#087e83">2013-02-05 archived ZIP</link>. GenerateOutput.cs: page/ring reader 1512-1605; format comments 1731-1785; frame state machine 1893-2037; output suppression 2061-2063; codebook/merge 2115-2170. Separate decompressor Program.cs 501-513 inserts sync. Partial decoder GenerateOutput.cs 672-688 and 782-813 describes native extraction and false positives. All three packages and source fingerprints are in decoder_source_manifest.json.','SmallR')
para('<b>S5.</b> Aviation Safety Council, ASC-TRT99-007, November 22, 1999, figure 4.2-2, printed44 / PDF45. Archived original government copy, 3,595,508 bytes, SHA-256 7517f5ec61fb3cc49f334601e730e2d5b8d87fcb9a515daf0e7a1bb9fc31b804. General hardware layout only.','SmallR')
sub('Updated go / no-go')
para('<b>GO:</b> the decoder-source gate is resolved and the selected raw-to-export reconciliation is demonstrated inside the validated complete final segment. The Boeing conversions explain all tested engineering cells, including the actual pressure-overlap and barometer cases.')
para('<b>NO-GO:</b> full-capture or full-CSV equivalence, earlier segments, the partial terminal frame, Hamming/parity certification, historical RAPS behavior, aircraft-specific door wiring/state, radio-height calibration, impact time, trajectory and suppression are not established. No claim in those categories follows from these numerical matches.')

def ornament(canvas,doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor('#ccd7de'));canvas.setLineWidth(.4)
    canvas.line(42,A4[1]-32,A4[0]-42,A4[1]-32)
    canvas.setFillColor(colors.HexColor('#566976'));canvas.setFont('Helvetica',7.2)
    canvas.drawString(42,A4[1]-24,'SCOOBY / R21 / RAW-WORD AUDIT')
    canvas.drawRightString(A4[0]-42,25,f'November 13, 2026  |  {doc.page}')
    canvas.restoreState()
doc=SimpleDocTemplate(str(P),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=48,bottomMargin=44,
 title='Scooby R21 - Raw Word to Engineering Export Reconciliation',author='Scooby audit')
doc.build(story,onFirstPage=ornament,onLaterPages=ornament)
(OUT/'R21_Raw_Word_Reconciliation_2026-11-13.txt').write_text(html.unescape(re.sub(r'<[^>]+>','','\n\n'.join(plain).replace('<br/>','\n')))+'\n')
print(P)
