#!/usr/bin/env python3
"""Independent bounded final-cell spot check after the raw ordering gate."""
from decimal import Decimal
import csv, json
from first_frames_reference import RAW, ROOT, Stream

def main():
    stream_number=1
    target_counter=50473
    metadata=[json.loads(l) for l in (ROOT/'decode_s1.jsonl').read_text().splitlines()]
    target=next(r for r in metadata if r['counter']==target_counter and not r['baseline'] and r['compressed'] and r['completed_words']==1020)
    base=max((r for r in metadata[:target['record']+1] if r['baseline'] and r['compressed'] and r['chain_known'] and r['completed_words']==1020 and not r['padding_bad'] and not r['sync_lost'] and not r['terminal']),key=lambda r:r['record'])
    decoder=Stream(RAW.read_bytes(),stream_number)
    decoder.bits.next_page=base['start_locator']['logical_128byte_page']
    decoder.bits.prepare()
    decoder.bits.bit=base['start_locator']['page_data_bit']
    frames=[]
    for _ in range(100):
        frame=decoder.frame()
        assert not frame['bad'] and not frame['sync_loss_code']
        assert frame['completed_recorded_words']==1020
        frames.append(frame)
        if frame['counter']==target_counter:break
    else:raise RuntimeError('Did not reach preselected counter within bounded replay')
    words={w['word']:w for w in frame['words'] if w['subframe']==4}
    raw_meta={r['key']:r for r in json.loads((ROOT/'reconciliation/raw_words.json').read_text())}
    locators=[]
    for number in [29,30,147]:
        independent=words[number]
        reference=raw_meta[f'S1:R{target["record"]}:SF4:W{number}']
        assert independent['decoded_value']==reference['word_value_decimal']
        assert independent['huffman_code']==reference['current_codeword']
        for endpoint,label in [('encoded_start','current_codeword_first_bit'),('encoded_last_bit','current_codeword_last_bit')]:
            physical=independent[endpoint]['physical_file_bit_index_msb0']
            assert physical//8==reference[label]['file_byte_offset']
            assert 7-physical%8==reference[label]['bit_in_byte_lsb0']
        locators.append({'word_key':reference['key'],'raw_value':independent['decoded_value'],
          'current_difference12':independent['difference12'],'current_huffman_code':independent['huffman_code'],
          'current_code_first_bit':reference['current_codeword_first_bit'],
          'current_code_last_bit':reference['current_codeword_last_bit'],
          'ancestry_entries_in_reconciliation':reference['ancestry_entries']})
    with (ROOT/'extracted/Flight77_Audit/sources/AAL77_tabular.csv').open(encoding='cp1252',newline='')as f:
        reader=csv.reader(f);rows=[]
        for row in reader:
            rows.append(row)
            assert reader.line_num==len(rows)
    w29,w30,w147=[words[w]['decoded_value']for w in [29,30,147]]
    pressure=128*((((w29>>2)&1023)^512)-512)+((w30>>2)&127)
    literal=128*((((w29>>2)&1023)^512)-512)+((((w30>>2)&1023)^512)-512)
    baro=Decimal(w147)/100
    assert pressure==Decimal(rows[37805][4])
    assert baro==Decimal(rows[37805][85])
    assert frame['words'][254]['decoded_value']==int(rows[37781][185])==1301
    comparisons=json.loads((ROOT/'reconciliation/comparisons.json').read_text())
    counter_joins=[r for r in comparisons if r['channel']=='aircraft_frame_counter']
    engineering=[r for r in comparisons if r['channel']!='aircraft_frame_counter']
    result={'verdict':'PASS_WITH_REPORTING_QUALIFICATIONS',
      'scope':'Static bounded reconciliation-code review plus direct independent last-baseline-to-final-delta replay; no broader dataset search',
      'reviewed_complete_cell_comparisons':len(comparisons),
      'engineering_value_matches':sum(r['match'] is True for r in engineering),
      'engineering_value_comparisons':len(engineering),
      'counter_join_checks':len(counter_joins),
      'counter_join_matches':sum(r['match'] is True for r in counter_joins),
      'raw_word_index_rule':'(subframe-1)*255 + word-2, because W1 is omitted',
      'csv_row_rule':'SF1 physical row from GD counter join; subsequent SF rows advance8 physical rows; 1-based cell row and column',
      'independent_spot_check':{'stream':1,'baseline_record':base['record'],'baseline_counter':base['counter'],
        'decoded_frames_in_replay':len(frames),'target_record':target['record'],'target_counter':target_counter,
        'raw_frame_counter':1301,'subframe':4,'csv_time_label':rows[37805][0],
        'E37806':{'words':{'W29':w29,'W30':w30},'bits_primary':'W29b3-12; W30b3-9',
          'csv_text':rows[37805][4],'boeing_value':pressure,'literal_TXT_value':literal},
        'CH37806':{'word':147,'raw_value':w147,'bits':'b1-12',
          'csv_text':rows[37805][85],'binary_count_div100':str(baro),
          'BCD_nibbles':[(w147>>k)&15 for k in [8,4,0]]},'raw_locator_checks':locators},
      'reporting_qualifications':[
        'Count56 engineering comparisons separately from4 counter join checks; the latter also establish the row join and are not independent engineering confirmations.',
        'Pressure primary extraction consumes W29b3-12 and W30b3-9; W30b3-12 belongs to the literalTXT alternative.',
        'A current codeword encodes a difference; raw_word_lineage.jsonl provides the full baseline-through-delta ancestry, so its physical bit offsets must not be called a standalone uncompressed12bit source word.',
        'Native sync bridge and raw counter/cycle gate preceded and did not read the engineering export; row joining then uses the separate documented frame-counter slot.',
        'Exact selected-cell agreement does not authenticate historical RAPS version/configuration or establish physical installation/state.'
      ]}
    output=ROOT/'agent_conversion/reconciliation_review.json'
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'verdict':result['verdict'],'engineering':len(engineering),'counter_joins':len(counter_joins),
      'replayed_frames':len(frames),'W29':w29,'W30':w30,'W147':w147,'E37806':pressure,'CH37806':str(baro),
      'literal_TXT_pressure':literal,'output':str(output)},indent=2))

if __name__=='__main__':main()
