#!/usr/bin/env python3
"""Independent raw-only ordering gate. No CSV input or engineering values."""
from pathlib import Path
import hashlib, json, struct
from first_frames_reference import RAW, Bits, Stream, ROOT

FIRST,LAST=49176,50473
START_RECORD={0:18666,1:18668}

def vector(blob, record):
    return struct.unpack_from('<1020H',blob,record*2040)

def main():
    raw=RAW.read_bytes()
    # Read the observed native words directly using the independently written
    # page/bit iterator, rather than the root's native probe output.
    bits=Bits(raw,0)
    bits.next_page=187629
    bits.prepare()
    bits.bit=670
    sequence=[];coords=[]
    for _ in range(11666):
        b,c=bits.nextbit();sequence.append(b);coords.append(c)
    def native_word(offset):
        return sum(sequence[offset+i]<<i for i in range(12))
    native_sync=[native_word(3072*i) for i in range(4)]
    marker=int(''.join(map(str,sequence[11630:11646])),2)
    baseline_type=int(''.join(map(str,sequence[11646:11650])),2)
    header_counter=int(''.join(map(str,sequence[11650:11666])),2)
    native_counter=native_word(255*12)
    native_cycle_word=native_word((2*256+255)*12)
    all_rows=[];unexpected=[];duplicates=[];baseline_checks=[]
    raw_counter_errors=[];cycle_errors=[];same_stream_errors=[]
    suffix=[]
    for stream in (0,1):
        metadata=[json.loads(l) for l in (ROOT/f'decode_s{stream}.jsonl').read_text().splitlines()]
        words=(ROOT/f'decode_s{stream}.words').read_bytes()
        prior_unique=None
        for row in metadata[START_RECORD[stream]:]:
            if not row['compressed'] or row['counter']>LAST:
                suffix.append({k:row[k] for k in ['stream','record','counter','compressed','completed_words','padding_bad','sync_lost','terminal']})
                continue
            if row['counter']<FIRST:
                unexpected.append({'reason':'counter below gate start','row':row});continue
            good=(row['chain_known'] and row['completed_words']==1020 and not row['padding_bad'] and not row['sync_lost'] and not row['terminal'])
            if not good: unexpected.append({'reason':'bad frame in bounded interval','row':row})
            values=vector(words,row['record'])
            if values[254]!=row['raw_sf1_w256'] or values[764]!=row['raw_sf3_w256']:
                unexpected.append({'reason':'binary vector metadata discrepancy','stream':stream,'record':row['record']})
            expected_counter=(native_counter+1+row['counter']-FIRST)&4095
            expected_cycle=((native_cycle_word>>8)+1+row['counter']-FIRST)&15
            if values[254]!=expected_counter:
                raw_counter_errors.append({'stream':stream,'record':row['record'],'counter':row['counter'],'actual':values[254],'expected':expected_counter})
            if (values[764]>>8)!=expected_cycle:
                cycle_errors.append({'stream':stream,'record':row['record'],'counter':row['counter'],'actual':values[764]>>8,'expected':expected_cycle})
            if row['baseline']:
                # Absolute baselines can be re-decoded without any earlier state.
                reference=Stream(raw,stream)
                loc=row['start_locator']
                reference.bits.next_page=loc['logical_128byte_page']
                reference.bits.prepare()
                reference.bits.bit=loc['page_data_bit']
                parsed=reference.frame()
                independent_values=tuple(w['decoded_value'] for w in parsed['words'])
                same=independent_values==values
                baseline_checks.append({'stream':stream,'record':row['record'],'counter':row['counter'],
                  'independent_python_counter':parsed['counter'],'equal_all1020_words':same,
                  'python_bad_flag':parsed['bad'],'raw_start':parsed['frame_start'],
                  'u16le_sha256':hashlib.sha256(struct.pack('<1020H',*values)).hexdigest()})
                if not same or parsed['counter']!=row['counter'] or parsed['bad']:
                    unexpected.append({'reason':'independent baseline mismatch','stream':stream,'record':row['record']})
            if prior_unique is not None and row['counter']==prior_unique['counter']:
                equal=values==vector(words,prior_unique['record'])
                duplicates.append({'stream':stream,'counter':row['counter'],'delta_record':prior_unique['record'],
                  'baseline_record':row['record'],'is_baseline':row['baseline'],'equal_all1020_words':equal})
                if not row['baseline'] or not equal:
                    unexpected.append({'reason':'nonidentical or nonbaseline duplicate','stream':stream,'record':row['record']})
            else:
                if prior_unique is not None and row['counter']!=prior_unique['counter']+2:
                    same_stream_errors.append({'stream':stream,'previous':prior_unique['counter'],'next':row['counter']})
                all_rows.append(row)
                prior_unique=row
    merged=sorted(all_rows,key=lambda r:r['counter'])
    counters=[r['counter'] for r in merged]
    expected=list(range(FIRST,LAST+1))
    gaps=sorted(set(expected)-set(counters))
    extra=sorted(set(counters)-set(expected))
    duplicate_unique=sorted(c for c in set(counters) if counters.count(c)>1)
    native_valid=(native_sync==[0x247,0x5B8,0xA47,0xDB8] and marker==0xFEFE and baseline_type==8 and header_counter==FIRST and native_counter==3 and native_cycle_word>>8==0)
    passed=native_valid and counters==expected and not any([unexpected,raw_counter_errors,cycle_errors,same_stream_errors,gaps,extra,duplicate_unique])
    result={
      'scope':'Raw ordering for final segment complete compressed counters49176..50473 only; no engineering export read',
      'verdict':'SCOPED_GO' if passed else 'NO_GO',
      'raw_sha256':hashlib.sha256(raw).hexdigest(),
      'native_observed_bridge':{'actual_sync_words_hex':[f'{w:03X}' for w in native_sync],
        'sync_spacing_bits':3072,'sync_locators':[coords[3072*i] for i in range(4)],
        'sf1_w256':native_counter,'sf3_w256':native_cycle_word,'cycle_nibble':native_cycle_word>>8,
        'marker_relative_bit':11630,'marker_hex':f'{marker:04X}',
        'following_type_bits':f'{baseline_type:04b}','following_counter16':header_counter,
        'following_header_locator':coords[11646],'valid':native_valid},
      'complete_unique_frames':len(merged),'counter_interval':[FIRST,LAST],
      'observed_raw_sf1_counter_interval':[merged[0]['raw_sf1_w256'],merged[-1]['raw_sf1_w256']],
      'raw_counter_formula':'(3 + 1 + compressed_counter - 49176) modulo4096',
      'cycle_formula':'(0 + 1 + compressed_counter - 49176) modulo16',
      'raw_counter_mismatches':raw_counter_errors,'cycle_mismatches':cycle_errors,
      'same_stream_counter_gaps':same_stream_errors,'merged_counter_gaps':gaps,'unexpected_counters':extra,
      'duplicated_unique_counters':duplicate_unique,'unexpected_frames':unexpected,
      'periodic_baseline_duplicates':duplicates,'independent_absolute_baseline_checks':baseline_checks,
      'excluded_after_complete_interval':suffix,
      'interpretation':[
        'Four native sync words are directly observed; none was inserted for this test.',
        'The native run establishes SF1/SF2/SF3/SF4 word orientation, then an adjacent FEFE/1000/16bit-counter header leads to the first compressed baseline.',
        'Recorded raw frame-counter and cycle fields bridge the transition and remain contiguous across the merged final segment.',
        'All absolute baselines in scope were independently decoded from raw bytes in Python; periodic baselines exactly duplicate the prior same-stream delta.',
        'This supports source-specific ordering and qualified raw-word addresses within the bounded complete-frame interval; it does not claim sync words are stored inside every compressed frame.',
        'Partial counter50474, postsegment bytes, earlier segments, Hamming/parity integrity, historical RAPS behavior, and physical aircraft states remain outside this gate.'
      ]}
    output=ROOT/'agent_conversion/final_segment_gate.json'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'verdict':result['verdict'],'complete_unique_frames':len(merged),
      'native_sync_hex':result['native_observed_bridge']['actual_sync_words_hex'],
      'duplicates':len(duplicates),'independent_baselines':len(baseline_checks),
      'raw_counter_errors':len(raw_counter_errors),'cycle_errors':len(cycle_errors),
      'unexpected_frames':len(unexpected),'gaps':gaps,'output':str(output)},indent=2))

if __name__=='__main__':main()
