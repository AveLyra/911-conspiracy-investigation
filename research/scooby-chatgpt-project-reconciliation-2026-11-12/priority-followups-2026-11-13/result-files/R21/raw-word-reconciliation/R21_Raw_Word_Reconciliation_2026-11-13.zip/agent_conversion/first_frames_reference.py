#!/usr/bin/env python3
"""Independent raw-only reference; no engineering conversion or sync insertion."""
from pathlib import Path
import hashlib, json, os, re, sys

ROOT = Path(os.environ.get('R21_WORK_DIR', str(Path(__file__).resolve().parent.parent))).expanduser().resolve()
RAW = ROOT / 'extracted/Flight77_Audit/sources/American_77.fdr'
SOURCE = ROOT / 'decoder_sources/extracted/AAL77FDRDecoder/AAL77FDRDecoder/GenerateOutput.cs'
CATEGORIES = [('0',0,0), ('10',1,2), ('110',3,3), ('1110',7,4),
 ('111100',15,5), ('1111100',31,6), ('1111010',63,7), ('111111',127,8),
 ('1111101',255,9), ('11110110',511,10), ('111101110',1023,11),
 ('1111011110',2047,2), ('1111011111',-1,0)]
BOOK = {}
for prefix, base, n in CATEGORIES:
    if not n: BOOK[prefix] = base
    else:
        for suffix in range(1 << n):
            sign, mag = divmod(suffix, 1 << (n-1))
            BOOK[prefix + format(suffix, f'0{n}b')] = 4096-base-mag if sign else base+mag
PREFIXES = {code[:i] for code in BOOK for i in range(1,len(code)+1)}

def source_fingerprint():
    """Record local source bytes when present, otherwise a supplied fingerprint.

    R21_DECODER_SOURCE_SHA256 is provenance metadata, not a substitute for an
    observed source-file hash. A conflicting local file is rejected.
    """
    supplied=os.environ.get('R21_DECODER_SOURCE_SHA256')
    if supplied is not None:
        if not re.fullmatch(r'[0-9a-fA-F]{64}',supplied):
            raise ValueError('R21_DECODER_SOURCE_SHA256 must contain 64 hexadecimal characters')
        supplied=supplied.lower()
    if SOURCE.is_file():
        observed=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
        if supplied is not None and supplied!=observed:
            raise ValueError('Supplied decoder-source fingerprint differs from local source bytes')
        return observed,'observed local source bytes'
    if supplied is not None:
        return supplied,'supplied fingerprint; source bytes unavailable in this run'
    return None,'source bytes and optional fingerprint unavailable in this run'

class Bits:
    def __init__(self, blob, stream):
        self.blob = blob
        offset = start = 0
        for pos in range(len(blob)-0x20000,-1,-0x20000):
            word = int.from_bytes(blob[pos:pos+2],'little')
            if word == 0xFE6B: offset = pos
            elif word == 0xFFFF: offset,start = pos,pos+0x20000
            else: break
        if start >= len(blob): start=offset
        self.offset=offset
        self.start=(start-offset)>>7
        self.total=(len(blob)-offset)>>7
        self.limit=self.total-1024
        self.next_page=stream*512+2
        self.page=None
        self.bit=1013
        self.consumed=0
    def bytepos(self,p):
        p+=self.start
        if p>=self.total:p-=self.total
        return self.offset+128*p
    def prepare(self):
        while self.page is None or self.bit>=1013:
            if self.next_page>=self.limit: raise EOFError('bounded ring end')
            self.logical=self.next_page
            self.base=self.bytepos(self.logical)
            self.page=self.blob[self.base:self.base+128]
            self.next_page+=1
            if self.next_page&511==0:self.next_page+=514
            self.bit=0
            if self.page==b'\xff'*128:
                self.page=None
                continue
            if self.next_page>=self.limit:raise EOFError('source next-page bound')
    def coordinate(self):
        self.prepare()
        wordpos=self.base+2*(self.bit//16)
        bytepos=wordpos+(1 if self.bit%16<8 else 0)
        return {'logical_page_128':self.logical,'physical_page_byte_offset':self.base,
          'page_data_bit_index':self.bit,'physical_word_byte_offset':wordpos,
          'word_bit_index_msb0':self.bit%16,
          'physical_file_bit_index_msb0':bytepos*8+self.bit%8,
          'stream_consumed_bit_index':self.consumed}
    def nextbit(self):
        self.prepare()
        coord=self.coordinate()
        p=2*(self.bit//16)
        word=int.from_bytes(self.page[p:p+2],'little')
        bit=(word>>(15-self.bit%16))&1
        self.bit+=1;self.consumed+=1
        return bit,coord
    def marker(self):
        self.prepare()
        if self.bit%16 or self.bit//16==63:return False
        p=2*(self.bit//16)
        return int.from_bytes(self.page[p:p+2],'little')==0xFEFE

class Stream:
    def __init__(self,blob,n):
        self.n=n;self.bits=Bits(blob,n);self.values=[0]*1020;self.counter=-1
    def frame(self):
        state='start';baseline=bad=lost=False;position=0;lastzero=-1
        code='';frame_type=counter_bits=0;words=[];first=self.bits.coordinate()
        while True:
            if state=='wait' and self.bits.marker():
                marker=self.bits.coordinate();self.bits.bit+=16;self.bits.consumed+=16
                break
            bit,coord=self.bits.nextbit()
            if state=='start':
                baseline=bool(bit)
                if baseline:state='type';count=0
                else:self.counter+=2;state='decode'
            elif state=='type':
                frame_type=2*frame_type+bit;count+=1
                if count==3:
                    if frame_type:bad=True;state='wait'
                    else:self.counter=0;state='counter'
            elif state=='counter':
                self.counter=2*self.counter+bit;counter_bits+=1
                if counter_bits==16:state='decode'
            elif state=='decode':
                if not code:encoded_start=coord
                if not bit:lastzero=position
                code+=str(bit)
                if code not in PREFIXES:raise ValueError(('invalid code',code,coord))
                if code in BOOK:
                    diff=BOOK[code]
                    if diff<0:lost=bad=True;state='wait'
                    else:
                        old=self.values[position]
                        value=((0 if baseline else old)+diff)&4095
                        self.values[position]=value
                        words.append({'recorded_word_index0':position,
                          'subframe':position//255+1,'word':position%255+2,
                          'previous_value':None if baseline else old,
                          'difference12':diff,'decoded_value':value,'huffman_code':code,
                          'encoded_start':encoded_start,'encoded_last_bit':coord})
                        position+=1;code=''
                        if position==1020:state='wait'
            elif state=='wait' and bit!=1:bad=True
        return {'stream':self.n,'counter':self.counter,'baseline':baseline,'bad':bad,
          'sync_loss_code':lost,'completed_recorded_words':position,
          'last_zero_word_index0':lastzero,'frame_start':first,'end_marker':marker,'words':words}

def main():
    blob=RAW.read_bytes()
    source_hash,source_hash_status=source_fingerprint()
    result={'raw_sha256':hashlib.sha256(blob).hexdigest(),
      'decoder_source_sha256':source_hash,'decoder_source_sha256_status':source_hash_status,
      'python':sys.version,'sync_words':'Absent from compressed stream; none inserted',
      'coordinate_convention':'0-based physical file bits, MSB0 within each byte; LE16 bit reading visits high byte then low byte',
      'special_2047_category':{k:v for k,v in BOOK.items() if k.startswith('1111011110')},'streams':[]}
    for n in (0,1):
        s=Stream(blob,n);attempts=[]
        for _ in range(10000):
            f=s.frame()
            if f['baseline'] and not f['bad'] and f['completed_recorded_words']==1020:
                baseline=f;break
            attempts.append({k:v for k,v in f.items() if k!='words'})
        else:raise RuntimeError('No good baseline in bounded scan')
        while True:
            f=s.frame()
            if not f['baseline'] and f['completed_recorded_words']:delta=f;break
        r={'number':n,'ring':{'file_offset':s.bits.offset,'start_page':s.bits.start,
          'total_pages':s.bits.total,'usable_pages':s.bits.limit},
          'rejected_before_baseline':attempts,'baseline':baseline,'following_delta':delta}
        result['streams'].append(r)
        print(json.dumps({'stream':n,'ring':r['ring'],'rejected':len(attempts),
          'baseline_counter':baseline['counter'],'delta_counter':delta['counter'],
          'baseline_word_count':len(baseline['words']),'delta_word_count':len(delta['words']),
          'baseline_first10':[x['decoded_value'] for x in baseline['words'][:10]],
          'delta_first10':[x['decoded_value'] for x in delta['words'][:10]]}))
    output=ROOT/'agent_conversion/first_frames_reference.json'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(output)
if __name__=='__main__':main()
