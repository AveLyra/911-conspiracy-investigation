#!/usr/bin/env python3
"""Read one fixed native-sync-to-baseline transition, without engineering conversion.

Target selected from independently scanned final four-sync run. Page order follows
Stutt's source-derived two-stream layout. Native 12-bit words are LSB first;
baseline headers are MSB first. Output retains storage-level bit locators.
"""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('raw', type=Path)
p.add_argument('output', type=Path)
a = p.parse_args()
raw = a.raw.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '18ad30f72f3d30e5958480252469a1780b51469c903a18c47761ed41fb3ac0f6'
base, ring, start_lp, first_bit = 170, 30720, 187629, 670
pagecount = (len(raw) - base) // 128
assert start_lp + 24 < (start_lp // 512 + 1) * 512
bits, locs, marks = [], [], []
for lp in range(start_lp, start_lp + 24):
    pp = (lp + ring) % pagecount
    fo = base + 128 * pp
    page = raw[fo:fo + 128]
    if page == b'\xff' * 128:
        continue
    start = len(bits)
    for k in range(1013):
        storage_word_offset = fo + 2 * (k // 16)
        w = int.from_bytes(page[2 * (k // 16):2 * (k // 16) + 2], 'little')
        n = 15 - k % 16
        bits.append((w >> n) & 1)
        locs.append({'logical_128byte_page': lp, 'physical_128byte_page': pp,
                     'page_data_bit': k, 'storage_word_file_byte': storage_word_offset,
                     'file_byte_offset': storage_word_offset + (n >= 8),
                     'bit_in_byte_lsb0': n % 8})
    for j in range(63):
        if int.from_bytes(page[j * 2:j * 2 + 2], 'little') == 0xfefe:
            marks.append((start + 16 * j, lp, fo + j * 2))

def native(q):
    return sum(bits[q + k] << k for k in range(12))

def big(q, n):
    return sum(bits[q + k] << (n - 1 - k) for k in range(n))

result = {'raw_sha256': hashlib.sha256(raw).hexdigest(),
          'target': 'final four-sync native run in stream 0',
          'last_strong_native_run': {'logical_start_page': start_lp,
                                    'first_page_data_bit': first_bit,
                                    'actual_sync_words': [native(first_bit + j * 3072) for j in range(4)],
                                    'sync_locators': [locs[first_bit + j * 3072] for j in range(4)]},
          'markers': []}
for q, lp, fo in marks:
    if q >= first_bit:
        result['markers'].append({'relative_stream_bit': q - first_bit,
                                  'logical_page': lp, 'marker_storage_word_file_byte': fo,
                                  'following_4bits': format(big(q + 16, 4), '04b'),
                                  'following_counter16': big(q + 20, 16),
                                  'header_first_bit_locator': locs[q + 16],
                                  'payload_first_bit_locator': locs[q + 36]})
a.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
