SCOOBY R01 — COMPLETE SEC PACKET INDEX AND SOURCE-LINKED RECONCILIATION
Audit date: 2026-11-14 UTC (official retrieval occurred 2026-11-13 in New York).

START HERE
Scooby_R01_Coverage_and_Reconciliation.pdf is the concise six-page report.
Scooby_R01_SEC_704_Page_Index.json is the authoritative complete index.
Scooby_R01_SEC_Pages.csv has one row for each physical PDF page.
Scooby_R01_SEC_Documents.csv lists document/attachment/section units.
Scooby_R01_Source_Linked_Reconciliation.json supplies bounded claims, evidence
classes, arithmetic and the foreign-referral matrix with page/Bates locators.

COVERAGE
704 physical pages; 616 pages assigned to identified units; 88 explicitly
unknown (73 redacted leaves, 10 blank leaves, 5 unresolved dividers); zero omitted.
170 primary index units plus two embedded text units. Units include sections
and dividers; this is not a reconstructed count of all hidden original documents.
Every unknown leaf has its own stable ID. Do not infer its neighbors' identity.

CANONICAL SOURCE
source/records-provided-9-11-commission.pdf is unchanged official SEC HTTP200
content: 74,063,160 bytes, 704 pages, SHA-256:
77b983db8bf9cc18697ceb645d849cd1f2c602ce717d8e385c1e19c50dfba8a7
https://www.sec.gov/files/records-provided-9-11-commission.pdf
Retrieval receipts, PDF metadata/XMP and bookmarks are in retrieval/.
The temporary response name in the original log was renamed to the canonical
source path; there is no missing second source copy.

HOW TO READ THE INDEX
PDF page numbers are one-based physical positions. pdf_pages governs actual
membership; start/end are only an envelope for non-contiguous documents.
Bates and printed page numbers are visible transcriptions, not inferred sequences.
Bookmark identifiers are metadata only and can conflict with visible handwriting.
Null is unknown/not confidently visible, not zero or proof of nonexistence.
Repeated small redaction-label placement/spacing is qualified at page level;
the unchanged source image governs. An identical fully redacted rendering is
not proof that the underlying hidden document is a duplicate.

EVIDENCE
All 704 page images were visually inspected at 200dpi using full-page contact
sheets, with enlarged/oriented reads where needed. Dense trade rows were not
certified as a transaction transcription. OCR is an uncorrected navigation aid.
ocr/ contains all 704 OCR texts; evidence/ contains native PDF text and page
render metadata/hashes. The large reproducible PNG cache is not bundled:
the source PDF itself is the primary page evidence. Links use #page=N.
To reproduce a page image with PyMuPDF1.26.6:
  python tools/prepare_pages.py --start 697 --end 699 --out reproduced_pages
Add --ocr to run Tesseract5.5.0 English psm3. Different tool versions can yield
different derivative hashes even when the source bytes are identical.

VALIDATION
From the extracted bundle root, run:
  python tools/validate_bundle.py
This checks the source, page coverage, memberships, CSVs, OCR hashes and all
manifest hashes. MANIFEST.json covers all files except itself and the optional
post-manifest validation output. audit/qa/ retains independent review results;
QA_Resolutions.json identifies corrections incorporated into the final outputs.

SUPPLEMENTARY SOURCES
The Cryptome combined Cella scan is a separate22-page source, fully indexed in
supplements/Cella_Scan_Index.json. Its hash identifies those retrieved bytes only;
no byte-for-byte match to an official NARA copy is established. The official
155-page financing monograph is separately retained, with selected relevant
pages inspected. Neither source is counted within the SEC704-page packet.

BOUNDARIES OF THE RECONCILIATION
The documented SEC/FBI no-evidence conclusion is preserved with its scope.
Numerical discrepancies are not foreknowledge evidence. No redacted identities,
beneficial-account joins or native database equivalence are guessed. No P&L or
statistical replication is attempted without complete trades, allocations,
prices, costs, model inputs and raw data. Consent/production status is distinct
from foreign referral merits. The prior R01 result served only as a work map.
Public/already-held sources only. No Deep Research, contacts, fees, records
requests or changes to pending matters.
